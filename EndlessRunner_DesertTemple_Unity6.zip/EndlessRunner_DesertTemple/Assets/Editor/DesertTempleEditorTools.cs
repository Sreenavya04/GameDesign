using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace DesertTemple
{
    /// <summary>
    /// One-click project setup and build helpers.
    /// The project auto-runs "Setup Project" the first time it is opened (creates the scene, folders,
    /// build settings and player settings), so nothing has to be wired manually.
    /// </summary>
    [InitializeOnLoad]
    public static class DesertTempleEditorTools
    {
        const string ScenePath = "Assets/Scenes/DesertTemple.unity";

        static DesertTempleEditorTools()
        {
            EditorApplication.delayCall += () =>
            {
                if (!File.Exists(ScenePath) && !EditorApplication.isPlayingOrWillChangePlaymode) SetupProject();
            };
        }

        [MenuItem("Tools/Desert Temple/Setup Project (scene, folders, settings)")]
        public static void SetupProject()
        {
            string[] folders =
            {
                "Assets/Scenes", "Assets/Prefabs", "Assets/Materials", "Assets/Textures", "Assets/Models",
                "Assets/Animations", "Assets/Audio", "Assets/UI"
            };
            foreach (string f in folders)
                if (!Directory.Exists(f)) Directory.CreateDirectory(f);

            // empty scene: GameBootstrap creates camera, light, managers, player, track and UI at runtime
            if (!File.Exists(ScenePath))
            {
                var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
                EditorSceneManager.SaveScene(scene, ScenePath);
            }

            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };

            PlayerSettings.companyName = "DesertTemple";
            PlayerSettings.productName = "Endless Runner - Desert Temple";
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
            PlayerSettings.runInBackground = false;

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            Debug.Log("[Desert Temple] Setup complete. Open Assets/Scenes/DesertTemple.unity and press Play.");
        }

        [MenuItem("Tools/Desert Temple/Open Game Scene")]
        public static void OpenScene()
        {
            if (!File.Exists(ScenePath)) SetupProject();
            EditorSceneManager.OpenScene(ScenePath);
        }

        [MenuItem("Tools/Desert Temple/Build Windows (.exe)")]
        public static void BuildWindows()
        {
            if (!File.Exists(ScenePath)) SetupProject();
            string outDir = "Builds/Windows";
            Directory.CreateDirectory(outDir);
            BuildPlayerOptions opts = new BuildPlayerOptions
            {
                scenes = new[] { ScenePath },
                locationPathName = outDir + "/EndlessRunner_DesertTemple.exe",
                target = BuildTarget.StandaloneWindows64,
                options = BuildOptions.None
            };
            var report = BuildPipeline.BuildPlayer(opts);
            Debug.Log("[Desert Temple] Windows build result: " + report.summary.result + " -> " + outDir);
        }
    }
}
