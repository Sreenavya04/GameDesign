using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI;

namespace DesertTemple
{
    /// <summary>
    /// Builds the whole uGUI interface from code (no manual Inspector setup needed) and keeps it in sync
    /// with the GameManager state: Main Menu, Settings, HUD, Pause menu and Game Over screen.
    /// Uses the legacy UI Text component with Unity's built-in font so no font import is required.
    /// </summary>
    public class UIManager : MonoBehaviour
    {
        public static UIManager Instance;

        Font font;
        Sprite circle;
        Canvas canvas;

        GameObject menuPanel, settingsPanel, hudPanel, pausePanel, overPanel;
        Text scoreText, distText, coinText, gemText, zoneText, highText;
        Text overScore, overCoins, overGems, overDist, overHigh, overNew;
        Text musicLabel, sfxLabel;
        Image[] hearts;
        Image progressFill;
        RectTransform progressFillRt, progressMarker;
        Image femaleFill, maleFill;

        GameObject[] puRows;
        RectTransform[] puBarRts;
        Text[] puTexts;
        int[] puSec;

        GameState lastState = (GameState)(-1);
        int lastScore = -1, lastCoins = -1, lastGems = -1, lastDist = -1, lastHealth = -1;
        string lastZone = "";

        static readonly Color Gold = new Color(1f, 0.80f, 0.25f);
        static readonly Color Sand = new Color(0.96f, 0.86f, 0.62f);
        static readonly Color Dark = new Color(0.12f, 0.07f, 0.03f, 0.88f);
        static readonly Color ButtonGold = new Color(0.88f, 0.64f, 0.22f);
        static readonly Color ButtonBrown = new Color(0.50f, 0.34f, 0.18f);

        void Awake() { Instance = this; }

        // ------------------------------------------------------------------
        //  Build
        // ------------------------------------------------------------------
        public void Build()
        {
            font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            if (font == null) font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            if (font == null) font = Font.CreateDynamicFontFromOSFont("Arial", 32);
            circle = MakeCircleSprite();

            EnsureEventSystem();

            GameObject cg = new GameObject("Canvas");
            cg.transform.SetParent(transform, false);
            canvas = cg.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 10;
            CanvasScaler scaler = cg.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 0.5f;
            cg.AddComponent<GraphicRaycaster>();

            BuildMenu(canvas.transform);
            BuildSettings(canvas.transform);
            BuildHud(canvas.transform);
            BuildPause(canvas.transform);
            BuildGameOver(canvas.transform);

            menuPanel.SetActive(false);
            settingsPanel.SetActive(false);
            hudPanel.SetActive(false);
            pausePanel.SetActive(false);
            overPanel.SetActive(false);
        }

        static void EnsureEventSystem()
        {
            if (Object.FindObjectsByType<EventSystem>(FindObjectsSortMode.None).Length > 0) return;
            GameObject es = new GameObject("EventSystem");
            es.AddComponent<EventSystem>();
#if ENABLE_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
            es.AddComponent<UnityEngine.InputSystem.UI.InputSystemUIInputModule>();
#else
            es.AddComponent<StandaloneInputModule>();
#endif
        }

        // ------------------------------------------------------------------
        //  Small UI toolkit
        // ------------------------------------------------------------------
        static Sprite MakeCircleSprite()
        {
            const int size = 64;
            Texture2D tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.filterMode = FilterMode.Bilinear;
            Color[] px = new Color[size * size];
            float c = (size - 1) * 0.5f;
            for (int y = 0; y < size; y++)
                for (int x = 0; x < size; x++)
                {
                    float d = Mathf.Sqrt((x - c) * (x - c) + (y - c) * (y - c));
                    float a = Mathf.Clamp01((c - d) / 1.5f);
                    px[y * size + x] = new Color(1, 1, 1, a);
                }
            tex.SetPixels(px);
            tex.Apply();
            return Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 100f);
        }

        static RectTransform NewRect(string name, Transform parent)
        {
            GameObject g = new GameObject(name, typeof(RectTransform));
            g.transform.SetParent(parent, false);
            return g.GetComponent<RectTransform>();
        }

        static void Stretch(RectTransform rt)
        {
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.offsetMin = Vector2.zero;
            rt.offsetMax = Vector2.zero;
        }

        static void Place(RectTransform rt, Vector2 anchor, Vector2 pivot, Vector2 pos, Vector2 size)
        {
            rt.anchorMin = anchor;
            rt.anchorMax = anchor;
            rt.pivot = pivot;
            rt.anchoredPosition = pos;
            rt.sizeDelta = size;
        }

        static Vector2 C { get { return new Vector2(0.5f, 0.5f); } }

        Image Img(Transform parent, string name, Color color)
        {
            RectTransform rt = NewRect(name, parent);
            Image im = rt.gameObject.AddComponent<Image>();
            im.color = color;
            return im;
        }

        Image Disc(Transform parent, Color color, Vector2 anchor, Vector2 pivot, Vector2 pos, float size)
        {
            Image im = Img(parent, "Disc", color);
            im.sprite = circle;
            im.raycastTarget = false;
            Place(im.rectTransform, anchor, pivot, pos, new Vector2(size, size));
            return im;
        }

        Text Txt(Transform parent, string s, int size, Color color, TextAnchor align, Vector2 anchor, Vector2 pivot, Vector2 pos, Vector2 box, bool outline = true)
        {
            RectTransform rt = NewRect("Text", parent);
            Text t = rt.gameObject.AddComponent<Text>();
            t.font = font;
            t.text = s;
            t.fontSize = size;
            t.color = color;
            t.alignment = align;
            t.raycastTarget = false;
            t.horizontalOverflow = HorizontalWrapMode.Overflow;
            t.verticalOverflow = VerticalWrapMode.Overflow;
            if (outline)
            {
                Outline o = rt.gameObject.AddComponent<Outline>();
                o.effectColor = new Color(0.12f, 0.06f, 0.02f, 1f);
                o.effectDistance = new Vector2(3f, -3f);
            }
            Place(rt, anchor, pivot, pos, box);
            return t;
        }

        Button Btn(Transform parent, string label, Vector2 anchor, Vector2 pivot, Vector2 pos, Vector2 size, int fontSize, UnityAction onClick)
        {
            RectTransform root = NewRect("Button_" + label, parent);
            Place(root, anchor, pivot, pos, size);
            Image border = root.gameObject.AddComponent<Image>();
            border.color = new Color(0.16f, 0.09f, 0.04f, 1f);

            RectTransform inner = NewRect("Fill", root);
            Stretch(inner);
            inner.offsetMin = new Vector2(6, 6);
            inner.offsetMax = new Vector2(-6, -6);
            Image fill = inner.gameObject.AddComponent<Image>();
            fill.color = ButtonGold;

            Button b = root.gameObject.AddComponent<Button>();
            b.targetGraphic = fill;
            ColorBlock cb = b.colors;
            cb.normalColor = Color.white;
            cb.highlightedColor = new Color(1f, 0.94f, 0.75f);
            cb.pressedColor = new Color(0.72f, 0.62f, 0.5f);
            cb.selectedColor = Color.white;
            cb.fadeDuration = 0.08f;
            b.colors = cb;

            Text t = Txt(root, label, fontSize, new Color(0.18f, 0.09f, 0.02f), TextAnchor.MiddleCenter, Vector2.zero, new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero, false);
            Stretch(t.rectTransform);

            b.onClick.AddListener(() =>
            {
                if (AudioManager.Instance != null) AudioManager.Instance.PlayClick();
                onClick();
            });
            return b;
        }

        static Image FillOf(Button b) { return (Image)b.targetGraphic; }

        GameObject FullPanel(Transform parent, string name, Color color)
        {
            Image im = Img(parent, name, color);
            Stretch(im.rectTransform);
            im.raycastTarget = color.a > 0.01f;
            return im.gameObject;
        }

        // ------------------------------------------------------------------
        //  Main menu
        // ------------------------------------------------------------------
        void BuildMenu(Transform parent)
        {
            menuPanel = FullPanel(parent, "MainMenu", new Color(0, 0, 0, 0));

            Image side = Img(menuPanel.transform, "SidePanel", new Color(0.09f, 0.05f, 0.02f, 0.78f));
            side.rectTransform.anchorMin = new Vector2(0, 0);
            side.rectTransform.anchorMax = new Vector2(0.42f, 1);
            side.rectTransform.offsetMin = Vector2.zero;
            side.rectTransform.offsetMax = Vector2.zero;
            Image edge = Img(side.transform, "Edge", Gold);
            edge.rectTransform.anchorMin = new Vector2(1, 0);
            edge.rectTransform.anchorMax = new Vector2(1, 1);
            edge.rectTransform.pivot = new Vector2(1, 0.5f);
            edge.rectTransform.sizeDelta = new Vector2(6, 0);
            edge.rectTransform.anchoredPosition = Vector2.zero;
            Transform p = side.transform;

            Txt(p, "ENDLESS", 128, Gold, TextAnchor.MiddleCenter, C, C, new Vector2(0, 380), new Vector2(800, 150));
            Txt(p, "RUNNER", 140, Gold, TextAnchor.MiddleCenter, C, C, new Vector2(0, 258), new Vector2(800, 160));
            Image banner = Img(p, "Banner", new Color(0.20f, 0.11f, 0.05f, 1f));
            Place(banner.rectTransform, C, C, new Vector2(0, 150), new Vector2(660, 84));
            banner.raycastTarget = false;
            Image bannerLine = Img(banner.transform, "Line", Gold);
            Place(bannerLine.rectTransform, new Vector2(0.5f, 0), new Vector2(0.5f, 0), Vector2.zero, new Vector2(660, 5));
            bannerLine.raycastTarget = false;
            Txt(banner.transform, "DESERT TEMPLE", 56, Sand, TextAnchor.MiddleCenter, C, C, Vector2.zero, new Vector2(660, 84));

            Txt(p, "CHOOSE YOUR ADVENTURER", 32, Sand, TextAnchor.MiddleCenter, C, C, new Vector2(0, 52), new Vector2(800, 50));
            Button female = Btn(p, "FEMALE", C, C, new Vector2(-185, -28), new Vector2(340, 90), 40, () => PickCharacter(0));
            Button male = Btn(p, "MALE", C, C, new Vector2(185, -28), new Vector2(340, 90), 40, () => PickCharacter(1));
            femaleFill = FillOf(female);
            maleFill = FillOf(male);

            Btn(p, "PLAY", C, C, new Vector2(0, -150), new Vector2(560, 120), 64, () => GameManager.Instance.StartRun());
            Btn(p, "SETTINGS", C, C, new Vector2(0, -282), new Vector2(560, 100), 46, () => { settingsPanel.SetActive(true); RefreshSettings(); });
            Btn(p, "EXIT", C, C, new Vector2(0, -392), new Vector2(560, 90), 42, QuitGame);

            highText = Txt(p, "HIGH SCORE: 0", 34, Sand, TextAnchor.MiddleCenter, C, C, new Vector2(0, -482), new Vector2(800, 50));

            Txt(menuPanel.transform, "A / D or Arrows: move   -   W / Space: jump   -   S: slide   -   P: pause      (swipe on touch screens)",
                28, Sand, TextAnchor.MiddleCenter, new Vector2(0.71f, 0), new Vector2(0.5f, 0), new Vector2(0, 28), new Vector2(1000, 50));

            RefreshCharacterButtons();
        }

        void PickCharacter(int g)
        {
            PlayerController.Instance.SetCharacter(g);
            RefreshCharacterButtons();
        }

        void RefreshCharacterButtons()
        {
            int sel = GameManager.SelectedCharacter;
            femaleFill.color = sel == 0 ? new Color(1f, 0.86f, 0.35f) : ButtonBrown;
            maleFill.color = sel == 1 ? new Color(1f, 0.86f, 0.35f) : ButtonBrown;
        }

        static void QuitGame()
        {
#if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
#else
            Application.Quit();
#endif
        }

        // ------------------------------------------------------------------
        //  Settings
        // ------------------------------------------------------------------
        void BuildSettings(Transform parent)
        {
            settingsPanel = FullPanel(parent, "Settings", new Color(0, 0, 0, 0.65f));
            Image box = Img(settingsPanel.transform, "Box", new Color(0.14f, 0.08f, 0.04f, 0.97f));
            Place(box.rectTransform, C, C, Vector2.zero, new Vector2(760, 640));
            Image top = Img(box.transform, "Top", Gold);
            Place(top.rectTransform, new Vector2(0.5f, 1), new Vector2(0.5f, 1), Vector2.zero, new Vector2(760, 8));
            Transform p = box.transform;

            Txt(p, "SETTINGS", 72, Gold, TextAnchor.MiddleCenter, C, C, new Vector2(0, 230), new Vector2(700, 100));
            Button music = Btn(p, "MUSIC: ON", C, C, new Vector2(0, 90), new Vector2(560, 100), 44,
                () => { AudioManager.Instance.SetMusic(!AudioManager.Instance.MusicOn); RefreshSettings(); });
            Button snd = Btn(p, "SOUND FX: ON", C, C, new Vector2(0, -35), new Vector2(560, 100), 44,
                () => { AudioManager.Instance.SetSfx(!AudioManager.Instance.SfxOn); RefreshSettings(); });
            musicLabel = music.GetComponentInChildren<Text>();
            sfxLabel = snd.GetComponentInChildren<Text>();
            Btn(p, "BACK", C, C, new Vector2(0, -190), new Vector2(560, 100), 44, () => settingsPanel.SetActive(false));
        }

        void RefreshSettings()
        {
            if (musicLabel != null) musicLabel.text = "MUSIC: " + (AudioManager.Instance.MusicOn ? "ON" : "OFF");
            if (sfxLabel != null) sfxLabel.text = "SOUND FX: " + (AudioManager.Instance.SfxOn ? "ON" : "OFF");
        }

        // ------------------------------------------------------------------
        //  HUD
        // ------------------------------------------------------------------
        void BuildHud(Transform parent)
        {
            hudPanel = FullPanel(parent, "HUD", new Color(0, 0, 0, 0));
            Transform p = hudPanel.transform;
            Vector2 tl = new Vector2(0, 1), tr = new Vector2(1, 1), tc = new Vector2(0.5f, 1), bc = new Vector2(0.5f, 0), ml = new Vector2(0, 0.5f);

            // pause button (top-left)
            Btn(p, "II", tl, tl, new Vector2(40, -40), new Vector2(110, 110), 56, () => GameManager.Instance.Pause());

            // hearts
            hearts = new Image[3];
            for (int i = 0; i < 3; i++)
            {
                Disc(p, new Color(0.12f, 0.05f, 0.03f, 1f), tl, tl, new Vector2(40 + i * 62, -162), 56);
                hearts[i] = Disc(p, new Color(0.9f, 0.15f, 0.2f, 1f), tl, tl, new Vector2(47 + i * 62, -169), 42);
            }

            // coins (top-right)
            Image coinBg = Img(p, "CoinBar", Dark);
            coinBg.raycastTarget = false;
            Place(coinBg.rectTransform, tr, tr, new Vector2(-40, -40), new Vector2(330, 84));
            Disc(coinBg.transform, Gold, new Vector2(0, 0.5f), new Vector2(0, 0.5f), new Vector2(12, 0), 64);
            Disc(coinBg.transform, new Color(0.85f, 0.55f, 0.08f), new Vector2(0, 0.5f), new Vector2(0, 0.5f), new Vector2(22, 0), 44);
            coinText = Txt(coinBg.transform, "0", 52, Color.white, TextAnchor.MiddleRight, new Vector2(1, 0.5f), new Vector2(1, 0.5f), new Vector2(-18, 0), new Vector2(220, 80));

            // gems
            Image gemBg = Img(p, "GemBar", Dark);
            gemBg.raycastTarget = false;
            Place(gemBg.rectTransform, tr, tr, new Vector2(-40, -134), new Vector2(330, 84));
            Image gem = Img(gemBg.transform, "Gem", new Color(0.2f, 0.55f, 1f));
            gem.raycastTarget = false;
            Place(gem.rectTransform, new Vector2(0, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(44, 0), new Vector2(40, 40));
            gem.rectTransform.localRotation = Quaternion.Euler(0, 0, 45);
            gemText = Txt(gemBg.transform, "0", 52, Color.white, TextAnchor.MiddleRight, new Vector2(1, 0.5f), new Vector2(1, 0.5f), new Vector2(-18, 0), new Vector2(220, 80));

            // score + distance (top-centre)
            Txt(p, "SCORE", 28, Sand, TextAnchor.MiddleCenter, tc, tc, new Vector2(0, -18), new Vector2(400, 40));
            scoreText = Txt(p, "0", 78, Color.white, TextAnchor.MiddleCenter, tc, tc, new Vector2(0, -58), new Vector2(600, 100));
            distText = Txt(p, "0 m", 40, Sand, TextAnchor.MiddleCenter, tc, tc, new Vector2(0, -158), new Vector2(400, 56));

            // active power-ups (left side)
            puRows = new GameObject[PowerUpManager.Count];
            puBarRts = new RectTransform[PowerUpManager.Count];
            puTexts = new Text[PowerUpManager.Count];
            puSec = new int[PowerUpManager.Count];
            for (int i = 0; i < PowerUpManager.Count; i++)
            {
                Image row = Img(p, "PowerUp_" + i, Dark);
                row.raycastTarget = false;
                Place(row.rectTransform, ml, ml, new Vector2(40, 150 - i * 76), new Vector2(340, 66));
                puRows[i] = row.gameObject;
                Disc(row.transform, PowerUpManager.Colors[i], new Vector2(0, 0.5f), new Vector2(0, 0.5f), new Vector2(10, 0), 46);
                puTexts[i] = Txt(row.transform, PowerUpManager.Names[i], 26, Color.white, TextAnchor.MiddleLeft, new Vector2(0, 1), new Vector2(0, 1), new Vector2(66, -4), new Vector2(270, 34));
                Image barBg = Img(row.transform, "BarBg", new Color(0, 0, 0, 0.6f));
                barBg.raycastTarget = false;
                Place(barBg.rectTransform, new Vector2(0, 0), new Vector2(0, 0), new Vector2(66, 8), new Vector2(256, 10));
                Image barFill = Img(barBg.transform, "BarFill", PowerUpManager.Colors[i]);
                barFill.raycastTarget = false;
                Stretch(barFill.rectTransform);
                puBarRts[i] = barFill.rectTransform;
                puRows[i].SetActive(false);
            }

            // progress bar + zone label (bottom)
            zoneText = Txt(p, "ZONE", 34, Sand, TextAnchor.MiddleCenter, bc, bc, new Vector2(0, 86), new Vector2(1100, 46));
            Image barBack = Img(p, "ProgressBack", new Color(0.12f, 0.06f, 0.03f, 0.9f));
            barBack.raycastTarget = false;
            Place(barBack.rectTransform, bc, bc, new Vector2(0, 40), new Vector2(1100, 38));
            progressFill = Img(barBack.transform, "ProgressFill", Gold);
            progressFill.raycastTarget = false;
            progressFillRt = progressFill.rectTransform;
            progressFillRt.anchorMin = new Vector2(0, 0);
            progressFillRt.anchorMax = new Vector2(0, 1);
            progressFillRt.pivot = new Vector2(0, 0.5f);
            progressFillRt.offsetMin = new Vector2(4, 4);
            progressFillRt.offsetMax = new Vector2(4, -4);
            Image marker = Disc(barBack.transform, new Color(1f, 0.95f, 0.8f), new Vector2(0, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, 52);
            progressMarker = marker.rectTransform;
        }

        // ------------------------------------------------------------------
        //  Pause + Game over
        // ------------------------------------------------------------------
        void BuildPause(Transform parent)
        {
            pausePanel = FullPanel(parent, "Pause", new Color(0, 0, 0, 0.6f));
            Image box = Img(pausePanel.transform, "Box", new Color(0.14f, 0.08f, 0.04f, 0.97f));
            Place(box.rectTransform, C, C, Vector2.zero, new Vector2(640, 720));
            Image top = Img(box.transform, "Top", Gold);
            Place(top.rectTransform, new Vector2(0.5f, 1), new Vector2(0.5f, 1), Vector2.zero, new Vector2(640, 8));
            Transform p = box.transform;
            Txt(p, "PAUSED", 84, Gold, TextAnchor.MiddleCenter, C, C, new Vector2(0, 250), new Vector2(600, 110));
            Btn(p, "RESUME", C, C, new Vector2(0, 90), new Vector2(460, 100), 46, () => GameManager.Instance.Resume());
            Btn(p, "RESTART", C, C, new Vector2(0, -30), new Vector2(460, 100), 46, () => GameManager.Instance.Restart());
            Btn(p, "MAIN MENU", C, C, new Vector2(0, -150), new Vector2(460, 100), 46, () => GameManager.Instance.GoToMenu());
        }

        void BuildGameOver(Transform parent)
        {
            overPanel = FullPanel(parent, "GameOver", new Color(0, 0, 0, 0.62f));
            Image box = Img(overPanel.transform, "Box", new Color(0.14f, 0.08f, 0.04f, 0.97f));
            Place(box.rectTransform, C, C, Vector2.zero, new Vector2(780, 900));
            Image top = Img(box.transform, "Top", new Color(0.85f, 0.2f, 0.15f));
            Place(top.rectTransform, new Vector2(0.5f, 1), new Vector2(0.5f, 1), Vector2.zero, new Vector2(780, 8));
            Transform p = box.transform;

            Txt(p, "GAME OVER", 88, new Color(1f, 0.45f, 0.25f), TextAnchor.MiddleCenter, C, C, new Vector2(0, 360), new Vector2(740, 110));
            Txt(p, "FINAL SCORE", 30, Sand, TextAnchor.MiddleCenter, C, C, new Vector2(0, 270), new Vector2(600, 40));
            overScore = Txt(p, "0", 100, Color.white, TextAnchor.MiddleCenter, C, C, new Vector2(0, 200), new Vector2(700, 120));
            overNew = Txt(p, "NEW HIGH SCORE!", 40, Gold, TextAnchor.MiddleCenter, C, C, new Vector2(0, 118), new Vector2(700, 56));
            overCoins = Txt(p, "Coins: 0", 44, Sand, TextAnchor.MiddleCenter, C, C, new Vector2(0, 50), new Vector2(700, 60));
            overGems = Txt(p, "Gems: 0", 44, Sand, TextAnchor.MiddleCenter, C, C, new Vector2(0, -15), new Vector2(700, 60));
            overDist = Txt(p, "Distance: 0 m", 44, Sand, TextAnchor.MiddleCenter, C, C, new Vector2(0, -80), new Vector2(700, 60));
            overHigh = Txt(p, "High score: 0", 44, Gold, TextAnchor.MiddleCenter, C, C, new Vector2(0, -145), new Vector2(700, 60));
            Btn(p, "RETRY", C, C, new Vector2(0, -250), new Vector2(520, 100), 50, () => GameManager.Instance.Restart());
            Btn(p, "MAIN MENU", C, C, new Vector2(0, -365), new Vector2(520, 100), 46, () => GameManager.Instance.GoToMenu());
        }

        // ------------------------------------------------------------------
        //  Per-frame sync
        // ------------------------------------------------------------------
        void Update()
        {
            GameManager gm = GameManager.Instance;
            if (gm == null || canvas == null) return;

            if (gm.State != lastState)
            {
                lastState = gm.State;
                menuPanel.SetActive(gm.State == GameState.Menu);
                if (gm.State != GameState.Menu) settingsPanel.SetActive(false);
                hudPanel.SetActive(gm.State != GameState.Menu);
                pausePanel.SetActive(gm.State == GameState.Paused);
                overPanel.SetActive(gm.State == GameState.GameOver);

                if (gm.State == GameState.Menu)
                {
                    highText.text = "HIGH SCORE: " + gm.HighScore;
                    RefreshCharacterButtons();
                }
                if (gm.State == GameState.GameOver)
                {
                    overScore.text = gm.Score.ToString();
                    overCoins.text = "Coins collected: " + gm.Coins;
                    overGems.text = "Gems: " + gm.Gems;
                    overDist.text = "Distance: " + Mathf.FloorToInt(gm.Distance) + " m";
                    overHigh.text = "High score: " + gm.HighScore;
                    overNew.gameObject.SetActive(gm.NewHighScore);
                }
                lastScore = lastCoins = lastGems = lastDist = lastHealth = -1;
            }

            if (gm.State == GameState.Menu) return;
            UpdateHud(gm);
        }

        void UpdateHud(GameManager gm)
        {
            if (gm.Score != lastScore) { lastScore = gm.Score; scoreText.text = lastScore.ToString(); }
            if (gm.Coins != lastCoins) { lastCoins = gm.Coins; coinText.text = lastCoins.ToString(); }
            if (gm.Gems != lastGems) { lastGems = gm.Gems; gemText.text = lastGems.ToString(); }
            int dist = Mathf.FloorToInt(gm.Distance);
            if (dist != lastDist) { lastDist = dist; distText.text = dist + " m"; }
            if (gm.Health != lastHealth)
            {
                lastHealth = gm.Health;
                for (int i = 0; i < hearts.Length; i++)
                    hearts[i].color = i < lastHealth ? new Color(0.9f, 0.15f, 0.2f, 1f) : new Color(0.25f, 0.2f, 0.2f, 0.8f);
            }

            string zone = TrackManager.ThemeNameAt(gm.Distance);
            if (zone != lastZone) { lastZone = zone; zoneText.text = "ZONE: " + zone.ToUpper(); }
            float prog = TrackManager.ThemeProgressAt(gm.Distance);
            progressFillRt.anchorMax = new Vector2(Mathf.Max(0.001f, prog), 1);
            progressFillRt.offsetMax = new Vector2(-4, -4);
            progressMarker.anchorMin = new Vector2(prog, 0.5f);
            progressMarker.anchorMax = new Vector2(prog, 0.5f);

            PowerUpManager pm = PowerUpManager.Instance;
            for (int i = 0; i < PowerUpManager.Count; i++)
            {
                PowerUpType type = (PowerUpType)i;
                bool active = pm.IsActive(type);
                if (puRows[i].activeSelf != active) puRows[i].SetActive(active);
                if (!active) { puSec[i] = -1; continue; }
                puBarRts[i].anchorMax = new Vector2(Mathf.Max(0.001f, pm.Fraction(type)), 1);
                int sec = Mathf.CeilToInt(pm.Remaining(type));
                if (sec != puSec[i]) { puSec[i] = sec; puTexts[i].text = PowerUpManager.Names[i] + "  " + sec + "s"; }
            }
        }
    }
}
