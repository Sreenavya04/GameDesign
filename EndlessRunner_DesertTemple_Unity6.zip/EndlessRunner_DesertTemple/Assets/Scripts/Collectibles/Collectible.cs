using UnityEngine;

namespace DesertTemple
{
    public enum CollectibleType
    {
        Coin, Ankh, Gem, Scarab, Idol,                 // score items
        Hourglass, SunOrb, PalmLeaf, Scroll,           // special relics
        SpeedBoost, Shield, Magnet, Invincibility, Multiplier // power-ups
    }

    /// <summary>A pickup. Spins, floats, gets attracted by the magnet and applies its effect when collected.</summary>
    public class Collectible : MonoBehaviour
    {
        public CollectibleType type;
        Transform visual;
        float phase;

        public static string KeyFor(CollectibleType t) { return "col_" + t; }

        public static GameObject Create(CollectibleType t)
        {
            GameObject root = new GameObject("Collectible_" + t);
            Collectible c = root.AddComponent<Collectible>();
            c.type = t;

            GameObject vis = new GameObject("Visual");
            vis.transform.SetParent(root.transform, false);
            c.visual = vis.transform;
            BuildVisual(t, vis.transform);

            SphereCollider sc = root.AddComponent<SphereCollider>();
            sc.isTrigger = true;
            sc.radius = IsPowerUp(t) ? 1.1f : 0.8f;
            sc.center = Vector3.zero;
            return root;
        }

        public static bool IsPowerUp(CollectibleType t) { return t >= CollectibleType.Hourglass; }

        void Awake()
        {
            if (visual == null && transform.childCount > 0) visual = transform.GetChild(0);
            phase = Random.value * 6.28f;
        }

        /// <summary>Called by the spawner after the object is fetched from the pool.</summary>
        public void ResetState()
        {
            phase = Random.value * 6.28f;
            if (visual != null) visual.localPosition = Vector3.zero;
            Collider c = GetComponent<Collider>();
            if (c != null) c.enabled = true;
        }

        bool Magnetic()
        {
            return type == CollectibleType.Coin || type == CollectibleType.Ankh || type == CollectibleType.Gem
                   || type == CollectibleType.Scarab || type == CollectibleType.Idol;
        }

        void Update()
        {
            if (visual != null)
            {
                visual.Rotate(0f, 120f * Time.deltaTime, 0f, Space.Self);
                Vector3 lp = visual.localPosition;
                lp.y = Mathf.Sin(Time.time * 3f + phase) * 0.15f;
                visual.localPosition = lp;
            }

            if (GameManager.Instance.State == GameState.Playing && Magnetic() && PowerUpManager.Instance.Magnet)
            {
                Vector3 pp = PlayerController.Instance.transform.position + Vector3.up * 0.9f;
                Vector3 d = pp - transform.position;
                if (d.sqrMagnitude < 14f * 14f && d.z < 12f)
                {
                    transform.position = Vector3.MoveTowards(transform.position, pp, (GameManager.Instance.Speed + 18f) * Time.deltaTime);
                }
            }
        }

        public void Collect()
        {
            GameManager gm = GameManager.Instance;
            PowerUpManager pm = PowerUpManager.Instance;
            switch (type)
            {
                case CollectibleType.Coin: gm.AddCoin(1); gm.AddScore(10); break;
                case CollectibleType.Ankh: gm.AddCoin(1); gm.AddScore(25); break;
                case CollectibleType.Gem: gm.AddGem(1); gm.AddScore(20); break;
                case CollectibleType.Scarab: gm.AddCoin(1); gm.AddScore(30); break;
                case CollectibleType.Idol: gm.AddCoin(1); gm.AddScore(40); break;
                case CollectibleType.Hourglass: pm.Activate(PowerUpType.TimeBonus, 6f); gm.AddScore(15); break;
                case CollectibleType.SunOrb: pm.Activate(PowerUpType.Shield, 12f); break;
                case CollectibleType.PalmLeaf: pm.Activate(PowerUpType.Magnet, 8f); break;
                case CollectibleType.Scroll: pm.Activate(PowerUpType.ScoreMultiplier, 10f); break;
                case CollectibleType.SpeedBoost: pm.Activate(PowerUpType.SpeedBoost, 6f); break;
                case CollectibleType.Shield: pm.Activate(PowerUpType.Shield, 12f); break;
                case CollectibleType.Magnet: pm.Activate(PowerUpType.Magnet, 10f); break;
                case CollectibleType.Invincibility: pm.Activate(PowerUpType.Invincibility, 7f); break;
                case CollectibleType.Multiplier: pm.Activate(PowerUpType.ScoreMultiplier, 10f); break;
            }

            if (IsPowerUp(type)) AudioManager.Instance.PlayPowerUp();
            else AudioManager.Instance.PlayCoin();
            PlayerController.Instance.TriggerCollect();
            gameObject.SetActive(false); // returned to the pool when its segment is recycled
        }

        // ------------------------------------------------------------------
        //  Visuals (all primitives so the project needs no external assets)
        // ------------------------------------------------------------------
        static void BuildVisual(CollectibleType t, Transform v)
        {
            Color gold = Pal.Gold;
            Color dark = Pal.Brown;
            switch (t)
            {
                case CollectibleType.Coin:
                    Prim.Cyl(v, Vector3.zero, new Vector3(0.75f, 0.06f, 0.75f), gold, 0.5f, new Vector3(90, 0, 0));
                    Prim.Cyl(v, Vector3.zero, new Vector3(0.58f, 0.075f, 0.58f), new Color(0.85f, 0.6f, 0.1f), 0.3f, new Vector3(90, 0, 0));
                    // engraved ankh on both faces (kept to 2 cubes per face for performance)
                    for (int s = -1; s <= 1; s += 2)
                    {
                        float z = 0.045f * s;
                        Prim.Cube(v, new Vector3(0, -0.02f, z), new Vector3(0.07f, 0.34f, 0.02f), gold, 0.6f);
                        Prim.Cube(v, new Vector3(0, 0.04f, z), new Vector3(0.24f, 0.06f, 0.02f), gold, 0.6f);
                    }
                    break;

                case CollectibleType.Ankh:
                    BuildAnkh(v, 1f, gold);
                    break;

                case CollectibleType.Gem:
                    Prim.Pyramid(v, new Vector3(0, 0f, 0), new Vector3(0.5f, 0.45f, 0.5f), new Color(0.15f, 0.5f, 1f), 0.8f);
                    Prim.Pyramid(v, new Vector3(0, 0f, 0), new Vector3(0.5f, 0.45f, 0.5f), new Color(0.2f, 0.6f, 1f), 0.8f, new Vector3(180, 0, 0));
                    break;

                case CollectibleType.Scarab:
                    Prim.Sphere(v, Vector3.zero, new Vector3(0.5f, 0.3f, 0.7f), new Color(0.08f, 0.55f, 0.45f), 0.3f);
                    Prim.Sphere(v, new Vector3(0, 0.02f, 0.38f), new Vector3(0.28f, 0.22f, 0.22f), gold, 0.4f);
                    Prim.Cube(v, new Vector3(0, 0.16f, -0.02f), new Vector3(0.03f, 0.03f, 0.62f), gold, 0.5f);
                    for (int i = -1; i <= 1; i++)
                    {
                        Prim.Cube(v, new Vector3(0.3f, -0.1f, i * 0.2f), new Vector3(0.18f, 0.04f, 0.05f), gold, 0.3f, new Vector3(0, 0, -20));
                        Prim.Cube(v, new Vector3(-0.3f, -0.1f, i * 0.2f), new Vector3(0.18f, 0.04f, 0.05f), gold, 0.3f, new Vector3(0, 0, 20));
                    }
                    break;

                case CollectibleType.Idol:
                    Prim.Cube(v, new Vector3(0, -0.32f, 0), new Vector3(0.45f, 0.1f, 0.3f), Pal.Teal, 0.2f);
                    Prim.Capsule(v, new Vector3(0, -0.05f, 0), new Vector3(0.28f, 0.28f, 0.24f), gold, 0.35f);
                    Prim.Sphere(v, new Vector3(0, 0.3f, 0.02f), new Vector3(0.26f, 0.24f, 0.24f), gold, 0.35f);
                    Prim.Pyramid(v, new Vector3(0.08f, 0.38f, 0.02f), new Vector3(0.1f, 0.2f, 0.06f), gold, 0.35f);
                    Prim.Pyramid(v, new Vector3(-0.08f, 0.38f, 0.02f), new Vector3(0.1f, 0.2f, 0.06f), gold, 0.35f);
                    Prim.Sphere(v, new Vector3(0.05f, 0.32f, 0.13f), new Vector3(0.04f, 0.04f, 0.03f), Pal.Teal, 1f);
                    Prim.Sphere(v, new Vector3(-0.05f, 0.32f, 0.13f), new Vector3(0.04f, 0.04f, 0.03f), Pal.Teal, 1f);
                    break;

                case CollectibleType.Hourglass:
                    Prim.Cube(v, new Vector3(0, 0.42f, 0), new Vector3(0.5f, 0.07f, 0.5f), dark);
                    Prim.Cube(v, new Vector3(0, -0.42f, 0), new Vector3(0.5f, 0.07f, 0.5f), dark);
                    Prim.Pyramid(v, new Vector3(0, 0f, 0), new Vector3(0.42f, 0.4f, 0.42f), new Color(1f, 0.85f, 0.45f), 0.5f);
                    Prim.Pyramid(v, new Vector3(0, 0f, 0), new Vector3(0.42f, 0.4f, 0.42f), new Color(1f, 0.85f, 0.45f), 0.5f, new Vector3(180, 0, 0));
                    Prim.Cube(v, new Vector3(0.22f, 0, 0.22f), new Vector3(0.05f, 0.8f, 0.05f), dark);
                    Prim.Cube(v, new Vector3(-0.22f, 0, -0.22f), new Vector3(0.05f, 0.8f, 0.05f), dark);
                    break;

                case CollectibleType.SunOrb:
                    Prim.Sphere(v, Vector3.zero, new Vector3(0.55f, 0.55f, 0.55f), gold, 0.9f);
                    for (int i = 0; i < 8; i++)
                    {
                        float a = i * 45f;
                        GameObject ray = Prim.Pyramid(v, Vector3.zero, new Vector3(0.16f, 0.3f, 0.16f), Pal.Fire, 0.8f);
                        ray.transform.localRotation = Quaternion.Euler(0, 0, -a);
                        ray.transform.localPosition = Quaternion.Euler(0, 0, -a) * new Vector3(0, 0.26f, 0);
                    }
                    break;

                case CollectibleType.PalmLeaf:
                    Prim.Sphere(v, Vector3.zero, new Vector3(0.28f, 0.85f, 0.04f), Pal.Green, 0.25f, new Vector3(0, 0, 25));
                    Prim.Cube(v, Vector3.zero, new Vector3(0.025f, 0.9f, 0.05f), new Color(0.12f, 0.35f, 0.12f), 0f, new Vector3(0, 0, 25));
                    break;

                case CollectibleType.Scroll:
                    Prim.Cyl(v, Vector3.zero, new Vector3(0.22f, 0.4f, 0.22f), new Color(0.95f, 0.85f, 0.6f), 0.15f, new Vector3(0, 0, 90));
                    Prim.Cyl(v, new Vector3(0.4f, 0, 0), new Vector3(0.12f, 0.04f, 0.12f), dark, 0f, new Vector3(0, 0, 90));
                    Prim.Cyl(v, new Vector3(-0.4f, 0, 0), new Vector3(0.12f, 0.04f, 0.12f), dark, 0f, new Vector3(0, 0, 90));
                    Prim.Cube(v, new Vector3(0, 0, 0.12f), new Vector3(0.6f, 0.04f, 0.02f), Pal.Teal);
                    Prim.Cube(v, new Vector3(0, 0.05f, 0.12f), new Vector3(0.45f, 0.03f, 0.02f), Pal.Teal);
                    break;

                // ---- power-ups (slightly bigger, glowing) ---------------------------------
                case CollectibleType.SpeedBoost:
                    Prim.Cube(v, new Vector3(0, -0.05f, 0), new Vector3(0.28f, 0.45f, 0.3f), new Color(0.65f, 0.4f, 0.2f), 0.1f);
                    Prim.Cube(v, new Vector3(0, -0.28f, 0.1f), new Vector3(0.28f, 0.14f, 0.5f), new Color(0.5f, 0.3f, 0.15f));
                    Prim.Cube(v, new Vector3(0.22f, 0.12f, 0), new Vector3(0.4f, 0.06f, 0.2f), Color.white, 0.6f, new Vector3(0, 0, 25));
                    Prim.Cube(v, new Vector3(0.28f, 0.2f, 0), new Vector3(0.36f, 0.06f, 0.2f), new Color(0.6f, 0.85f, 1f), 0.8f, new Vector3(0, 0, 35));
                    Prim.Cube(v, new Vector3(-0.22f, 0.12f, 0), new Vector3(0.4f, 0.06f, 0.2f), Color.white, 0.6f, new Vector3(0, 0, -25));
                    Prim.Cube(v, new Vector3(-0.28f, 0.2f, 0), new Vector3(0.36f, 0.06f, 0.2f), new Color(0.6f, 0.85f, 1f), 0.8f, new Vector3(0, 0, -35));
                    break;

                case CollectibleType.Shield:
                    Prim.Sphere(v, Vector3.zero, new Vector3(0.75f, 0.85f, 0.18f), new Color(0.15f, 0.45f, 0.95f), 0.7f);
                    Prim.Sphere(v, new Vector3(0, 0, 0.05f), new Vector3(0.6f, 0.7f, 0.16f), new Color(0.3f, 0.65f, 1f), 0.8f);
                    BuildAnkh(v, 0.6f, gold, 0.1f);
                    break;

                case CollectibleType.Magnet:
                    Prim.Cube(v, new Vector3(-0.25f, 0, 0), new Vector3(0.18f, 0.6f, 0.18f), new Color(0.9f, 0.15f, 0.2f), 0.5f);
                    Prim.Cube(v, new Vector3(0.25f, 0, 0), new Vector3(0.18f, 0.6f, 0.18f), new Color(0.9f, 0.15f, 0.2f), 0.5f);
                    Prim.Cube(v, new Vector3(0, 0.34f, 0), new Vector3(0.68f, 0.18f, 0.18f), new Color(0.9f, 0.15f, 0.2f), 0.5f);
                    Prim.Cube(v, new Vector3(-0.25f, -0.4f, 0), new Vector3(0.2f, 0.2f, 0.2f), new Color(0.85f, 0.9f, 1f), 0.6f);
                    Prim.Cube(v, new Vector3(0.25f, -0.4f, 0), new Vector3(0.2f, 0.2f, 0.2f), new Color(0.85f, 0.9f, 1f), 0.6f);
                    break;

                case CollectibleType.Invincibility:
                    Prim.Cyl(v, Vector3.zero, new Vector3(0.8f, 0.06f, 0.8f), gold, 0.7f, new Vector3(90, 0, 0));
                    Prim.Cyl(v, new Vector3(0, 0, 0.02f), new Vector3(0.62f, 0.06f, 0.62f), Pal.DarkBrown, 0f, new Vector3(90, 0, 0));
                    Prim.Sphere(v, new Vector3(0, 0, 0.04f), new Vector3(0.36f, 0.2f, 0.08f), Color.white, 0.4f);
                    Prim.Sphere(v, new Vector3(0, 0, 0.08f), new Vector3(0.16f, 0.16f, 0.06f), Pal.Teal, 1f);
                    break;

                case CollectibleType.Multiplier:
                    Prim.Cyl(v, Vector3.zero, new Vector3(0.8f, 0.08f, 0.8f), gold, 0.7f, new Vector3(90, 0, 0));
                    Prim.Cyl(v, new Vector3(0, 0, 0.02f), new Vector3(0.64f, 0.08f, 0.64f), Pal.Brown, 0f, new Vector3(90, 0, 0));
                    // "x2" built from cubes, front face
                    Prim.Cube(v, new Vector3(-0.15f, 0, 0.07f), new Vector3(0.05f, 0.28f, 0.03f), gold, 0.9f, new Vector3(0, 0, 40));
                    Prim.Cube(v, new Vector3(-0.15f, 0, 0.07f), new Vector3(0.05f, 0.28f, 0.03f), gold, 0.9f, new Vector3(0, 0, -40));
                    Prim.Cube(v, new Vector3(0.14f, 0.12f, 0.07f), new Vector3(0.2f, 0.05f, 0.03f), gold, 0.9f);
                    Prim.Cube(v, new Vector3(0.14f, 0.0f, 0.07f), new Vector3(0.2f, 0.05f, 0.03f), gold, 0.9f);
                    Prim.Cube(v, new Vector3(0.14f, -0.12f, 0.07f), new Vector3(0.2f, 0.05f, 0.03f), gold, 0.9f);
                    Prim.Cube(v, new Vector3(0.22f, 0.06f, 0.07f), new Vector3(0.05f, 0.12f, 0.03f), gold, 0.9f);
                    Prim.Cube(v, new Vector3(0.06f, -0.06f, 0.07f), new Vector3(0.05f, 0.12f, 0.03f), gold, 0.9f);
                    break;
            }

            if (IsPowerUp(t)) v.localScale = Vector3.one * 1.25f;
        }

        static void BuildAnkh(Transform v, float scale, Color gold, float zOffset = 0f)
        {
            Prim.Cube(v, new Vector3(0, -0.12f * scale, zOffset), new Vector3(0.12f, 0.6f, 0.08f) * scale, gold, 0.6f);
            Prim.Cube(v, new Vector3(0, 0.02f * scale, zOffset), new Vector3(0.42f, 0.1f, 0.08f) * scale, gold, 0.6f);
            Prim.Sphere(v, new Vector3(0, 0.26f * scale, zOffset), new Vector3(0.34f, 0.34f, 0.08f) * scale, gold, 0.6f);
            Prim.Sphere(v, new Vector3(0, 0.26f * scale, zOffset + 0.01f), new Vector3(0.17f, 0.17f, 0.09f) * scale, Pal.DarkBrown);
        }
    }
}
