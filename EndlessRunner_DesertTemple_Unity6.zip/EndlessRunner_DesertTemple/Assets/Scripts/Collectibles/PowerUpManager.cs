using UnityEngine;

namespace DesertTemple
{
    public enum PowerUpType { SpeedBoost, Shield, Magnet, Invincibility, ScoreMultiplier, TimeBonus }

    /// <summary>Tracks active power-ups, their remaining time, and exposes their effects.</summary>
    public class PowerUpManager : MonoBehaviour
    {
        public static PowerUpManager Instance;

        public const int Count = 6;
        readonly float[] remaining = new float[Count];
        readonly float[] total = new float[Count];

        public static readonly string[] Names =
        {
            "SPEED BOOST", "SHIELD", "MAGNET", "INVINCIBLE", "SCORE x2", "TIME BONUS"
        };

        public static readonly Color[] Colors =
        {
            new Color(0.35f, 0.65f, 1f),
            new Color(0.25f, 0.55f, 1f),
            new Color(0.95f, 0.25f, 0.30f),
            new Color(1f, 0.78f, 0.18f),
            new Color(1f, 0.70f, 0.10f),
            new Color(0.95f, 0.85f, 0.45f)
        };

        void Awake() { Instance = this; }

        void Update()
        {
            if (GameManager.Instance.State != GameState.Playing) return;
            for (int i = 0; i < Count; i++)
            {
                if (remaining[i] > 0f)
                {
                    remaining[i] -= Time.deltaTime;
                    if (remaining[i] < 0f) remaining[i] = 0f;
                }
            }
        }

        public void Activate(PowerUpType type, float duration)
        {
            int i = (int)type;
            remaining[i] = duration;
            total[i] = duration;
            AudioManager.Instance.PlayPowerUp();
        }

        public bool IsActive(PowerUpType type) { return remaining[(int)type] > 0f; }
        public float Remaining(PowerUpType type) { return remaining[(int)type]; }
        public float Fraction(PowerUpType type)
        {
            int i = (int)type;
            return total[i] <= 0f ? 0f : Mathf.Clamp01(remaining[i] / total[i]);
        }

        public bool Invincible
        {
            get { return IsActive(PowerUpType.Invincibility) || IsActive(PowerUpType.SpeedBoost); }
        }

        public bool Magnet { get { return IsActive(PowerUpType.Magnet); } }

        public float SpeedMultiplier
        {
            get
            {
                float m = 1f;
                if (IsActive(PowerUpType.SpeedBoost)) m *= 1.5f;
                if (IsActive(PowerUpType.TimeBonus)) m *= 0.75f;
                return m;
            }
        }

        public int ScoreMultiplier { get { return IsActive(PowerUpType.ScoreMultiplier) ? 2 : 1; } }

        /// <summary>Uses up the shield if active. Returns true if a collision was absorbed.</summary>
        public bool ConsumeShield()
        {
            if (!IsActive(PowerUpType.Shield)) return false;
            remaining[(int)PowerUpType.Shield] = 0f;
            return true;
        }

        public void ResetAll()
        {
            for (int i = 0; i < Count; i++) { remaining[i] = 0f; total[i] = 0f; }
        }
    }
}
