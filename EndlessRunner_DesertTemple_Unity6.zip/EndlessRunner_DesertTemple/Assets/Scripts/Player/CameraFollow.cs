using UnityEngine;

namespace DesertTemple
{
    /// <summary>Third-person follow camera. In the menu it shows the character from the front-side.</summary>
    public class CameraFollow : MonoBehaviour
    {
        static float shakeAmount;

        public Vector3 followOffset = new Vector3(0f, 4.2f, -7.5f);
        public Vector3 lookAhead = new Vector3(0f, 1.6f, 7f);
        Camera cam;
        Vector3 smoothPos;
        Quaternion smoothRot = Quaternion.identity;
        bool initialised;

        public static void Shake(float amount) { shakeAmount = Mathf.Max(shakeAmount, amount); }

        void Awake() { cam = GetComponent<Camera>(); }

        void LateUpdate()
        {
            if (PlayerController.Instance == null || GameManager.Instance == null) return;
            Transform p = PlayerController.Instance.transform;
            GameManager gm = GameManager.Instance;

            Vector3 desiredPos;
            Vector3 lookTarget;

            if (gm.State == GameState.Menu)
            {
                // character appears on the right side of the screen, UI sits on the left
                desiredPos = p.position + new Vector3(-1.2f, 1.5f, 4.0f);
                lookTarget = p.position + new Vector3(-1.9f, 1.05f, 0f);
            }
            else
            {
                // follow lane position softly so lane changes feel smooth
                float x = Mathf.Lerp(0f, p.position.x, 0.55f);
                desiredPos = new Vector3(x + followOffset.x, p.position.y * 0.4f + followOffset.y, p.position.z + followOffset.z);
                lookTarget = new Vector3(x * 0.6f, 1.2f + p.position.y * 0.3f, p.position.z + lookAhead.z);
            }

            float dt = Time.unscaledDeltaTime;
            if (!initialised)
            {
                smoothPos = desiredPos;
                initialised = true;
            }
            float follow = gm.State == GameState.Menu ? 3f : 12f;
            // when the state just switched the position blends because of the lower menu follow speed
            smoothPos = Vector3.Lerp(smoothPos, desiredPos, 1f - Mathf.Exp(-follow * dt));

            Quaternion desiredRot = Quaternion.LookRotation(lookTarget - smoothPos, Vector3.up);
            smoothRot = Quaternion.Slerp(smoothRot, desiredRot, 1f - Mathf.Exp(-(follow + 2f) * dt));

            Vector3 shake = Vector3.zero;
            if (shakeAmount > 0.01f)
            {
                shake = Random.insideUnitSphere * shakeAmount * 0.25f;
                shakeAmount = Mathf.MoveTowards(shakeAmount, 0f, dt * 2.2f);
            }

            transform.position = smoothPos + shake;
            transform.rotation = smoothRot;

            if (cam != null)
            {
                float targetFov = gm.State == GameState.Menu ? 45f : 62f + Mathf.Clamp01((gm.Speed - 12f) / 25f) * 14f;
                cam.fieldOfView = Mathf.Lerp(cam.fieldOfView, targetFov, 3f * dt);
            }
        }

        /// <summary>Snap the camera to its target (used after a restart).</summary>
        public void Snap() { initialised = false; }
    }
}
