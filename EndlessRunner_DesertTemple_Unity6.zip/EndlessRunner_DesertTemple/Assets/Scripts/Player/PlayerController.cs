using UnityEngine;

namespace DesertTemple
{
    /// <summary>
    /// Three-lane runner: automatic forward movement, lane changes, jump, slide, health and collisions.
    /// Requires a (kinematic) Rigidbody and a CapsuleCollider so trigger events fire.
    /// </summary>
    [RequireComponent(typeof(Rigidbody))]
    [RequireComponent(typeof(CapsuleCollider))]
    public class PlayerController : MonoBehaviour
    {
        public static PlayerController Instance;

        public const float LaneWidth = 3f;
        public float laneSpeed = 26f;
        public float jumpVelocity = 12.5f;
        public float gravity = -38f;
        public float slideDuration = 0.8f;

        int lane;               // -1, 0, 1
        float vy;
        bool grounded = true;
        float slideTimer;
        bool slideQueued;
        float invulnTimer;

        CapsuleCollider capsule;
        Rigidbody body;
        PlayerAnimator anim;
        CharacterRig rig;
        int currentCharacter = -1;

        public int Lane { get { return lane; } }
        public float LaneX { get { return lane * LaneWidth; } }
        public bool IsSliding { get { return slideTimer > 0f; } }

        void Awake()
        {
            Instance = this;
            body = GetComponent<Rigidbody>();
            body.isKinematic = true;
            body.useGravity = false;
            body.interpolation = RigidbodyInterpolation.None;
            capsule = GetComponent<CapsuleCollider>();
            capsule.direction = 1;
            capsule.radius = 0.32f;
            SetCapsule(false);
            anim = gameObject.AddComponent<PlayerAnimator>();
        }

        void SetCapsule(bool sliding)
        {
            if (sliding) { capsule.height = 0.7f; capsule.center = new Vector3(0, 0.35f, 0); }
            else { capsule.height = 1.8f; capsule.center = new Vector3(0, 0.9f, 0); }
        }

        public void SetCharacter(int gender)
        {
            if (gender == currentCharacter && rig != null) return;
            if (rig != null && rig.modelRoot != null) Destroy(rig.modelRoot.gameObject);
            currentCharacter = gender;
            rig = CharacterBuilder.Build(gender, transform);
            anim.SetRig(rig);
            GameManager.SelectedCharacter = gender;
        }

        public void ResetPlayer()
        {
            transform.position = Vector3.zero;
            lane = 0;
            vy = 0f;
            grounded = true;
            slideTimer = 0f;
            slideQueued = false;
            invulnTimer = 0f;
            SetCapsule(false);
            if (rig != null)
            {
                anim.SetRig(rig);
                anim.SetBlink(true);
            }
            anim.SetState(PlayerAnimator.AnimState.Idle);
            anim.SetLean(0f);
        }

        public void TriggerCollect() { anim.TriggerCollect(); }

        void Update()
        {
            GameManager gm = GameManager.Instance;
            if (gm == null) return;

            if (gm.State == GameState.Menu)
            {
                anim.SetState(PlayerAnimator.AnimState.Idle);
                anim.SetLean(0f);
                return;
            }
            if (gm.State != GameState.Playing) return;

            float dt = Time.deltaTime;

            // ---------- input ----------
            if (InputHelper.Left) { lane = Mathf.Max(-1, lane - 1); AudioManager.Instance.PlaySwish(); }
            if (InputHelper.Right) { lane = Mathf.Min(1, lane + 1); AudioManager.Instance.PlaySwish(); }
            if (InputHelper.Jump && grounded)
            {
                vy = jumpVelocity;
                grounded = false;
                EndSlide();
                AudioManager.Instance.PlayJump();
            }
            if (InputHelper.Slide)
            {
                if (grounded) StartSlide();
                else { vy = -22f; slideQueued = true; }
            }

            // ---------- movement ----------
            Vector3 pos = transform.position;
            pos.z += gm.Speed * dt;
            float targetX = lane * LaneWidth;
            pos.x = Mathf.MoveTowards(pos.x, targetX, laneSpeed * dt);

            if (!grounded)
            {
                vy += gravity * dt;
                pos.y += vy * dt;
                if (pos.y <= 0f)
                {
                    pos.y = 0f;
                    vy = 0f;
                    grounded = true;
                    if (slideQueued) { slideQueued = false; StartSlide(); }
                }
            }
            transform.position = pos;

            // ---------- slide timer ----------
            if (slideTimer > 0f)
            {
                slideTimer -= dt;
                if (slideTimer <= 0f) EndSlide();
            }

            // ---------- invulnerability blink ----------
            if (invulnTimer > 0f)
            {
                invulnTimer -= dt;
                anim.SetBlink(Mathf.FloorToInt(invulnTimer * 12f) % 2 == 0);
                if (invulnTimer <= 0f) anim.SetBlink(true);
            }

            // ---------- animation state ----------
            anim.SetLean((targetX - pos.x) / LaneWidth);
            if (anim.State != PlayerAnimator.AnimState.Stumble)
            {
                if (!grounded) anim.SetState(PlayerAnimator.AnimState.Jump);
                else if (slideTimer > 0f) anim.SetState(PlayerAnimator.AnimState.Slide);
                else anim.SetState(PlayerAnimator.AnimState.Run);
            }
            else if (!grounded || slideTimer > 0f)
            {
                anim.SetState(!grounded ? PlayerAnimator.AnimState.Jump : PlayerAnimator.AnimState.Slide);
            }
        }

        void StartSlide()
        {
            slideTimer = slideDuration;
            SetCapsule(true);
            AudioManager.Instance.PlaySlide();
        }

        void EndSlide()
        {
            slideTimer = 0f;
            SetCapsule(false);
        }

        // ---------- collisions ----------
        void OnTriggerEnter(Collider other)
        {
            if (GameManager.Instance.State != GameState.Playing) return;

            Collectible c = other.GetComponentInParent<Collectible>();
            if (c != null) { c.Collect(); return; }

            Obstacle o = other.GetComponentInParent<Obstacle>();
            if (o != null && !o.Smashed) HitObstacle(o);
        }

        void HitObstacle(Obstacle o)
        {
            PowerUpManager pm = PowerUpManager.Instance;
            GameManager gm = GameManager.Instance;

            if (pm.Invincible)
            {
                o.Smash();
                AudioManager.Instance.PlayHit();
                CameraFollow.Shake(0.25f);
                return;
            }
            if (pm.ConsumeShield())
            {
                o.Smash();
                AudioManager.Instance.PlayHit();
                CameraFollow.Shake(0.3f);
                return;
            }
            if (invulnTimer > 0f) return;

            bool dead = gm.Damage(o.damage);
            AudioManager.Instance.PlayHit();
            CameraFollow.Shake(0.6f);
            if (dead)
            {
                EndSlide();
                anim.SetBlink(true);
                anim.SetState(PlayerAnimator.AnimState.Fall);
                gm.GameOver();
            }
            else
            {
                invulnTimer = 1.6f;
                anim.SetState(PlayerAnimator.AnimState.Stumble);
            }
        }
    }
}
