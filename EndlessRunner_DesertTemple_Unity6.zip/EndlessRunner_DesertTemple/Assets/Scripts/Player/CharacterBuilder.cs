using UnityEngine;

namespace DesertTemple
{
    /// <summary>References to the body parts of a procedurally built character.</summary>
    public class CharacterRig
    {
        public Transform modelRoot;   // feet pivot
        public Transform hips;        // pivot at hip height
        public Transform lArm, rArm, lLeg, rLeg;
        public Transform hair;        // ponytail / headband tail
        public Transform scarfTail;
        public Renderer[] renderers;
    }

    public static class CharacterBuilder
    {
        // gender: 0 = female adventurer, 1 = male adventurer
        public static CharacterRig Build(int gender, Transform parent)
        {
            CharacterRig rig = new CharacterRig();
            GameObject root = new GameObject(gender == 0 ? "Model_Female" : "Model_Male");
            root.transform.SetParent(parent, false);
            rig.modelRoot = root.transform;

            GameObject hipsGo = new GameObject("Hips");
            hipsGo.transform.SetParent(root.transform, false);
            hipsGo.transform.localPosition = new Vector3(0, 0.95f, 0);
            rig.hips = hipsGo.transform;

            bool female = gender == 0;
            Color skin = female ? Pal.Skin : new Color(0.78f, 0.55f, 0.38f);
            Color pants = female ? new Color(0.95f, 0.93f, 0.88f) : new Color(0.78f, 0.68f, 0.48f);
            Color top = female ? new Color(0.86f, 0.72f, 0.52f) : new Color(0.45f, 0.28f, 0.14f);
            Color boots = new Color(0.40f, 0.24f, 0.12f);
            Color scarf = female ? new Color(0.12f, 0.62f, 0.78f) : new Color(0.78f, 0.15f, 0.12f);
            Color hairC = new Color(0.07f, 0.05f, 0.05f);
            Color belt = new Color(0.30f, 0.18f, 0.09f);

            float w = female ? 1f : 1.18f; // shoulder width multiplier
            Transform h = rig.hips;

            // torso
            Prim.Cube(h, new Vector3(0, 0.30f, 0), new Vector3(0.40f * w, 0.52f, 0.24f), top);
            Prim.Cube(h, new Vector3(0, 0.03f, 0), new Vector3(0.42f * w, 0.08f, 0.26f), belt);
            Prim.Cube(h, new Vector3(0, 0.03f, 0.135f), new Vector3(0.1f, 0.08f, 0.02f), Pal.Gold, 0.4f);
            if (!female)
            {
                Prim.Cube(h, new Vector3(0, 0.34f, 0.125f), new Vector3(0.20f, 0.40f, 0.02f), new Color(0.88f, 0.74f, 0.55f)); // bare chest strip
            }
            else
            {
                Prim.Cube(h, new Vector3(0, 0.40f, 0.125f), new Vector3(0.34f, 0.10f, 0.02f), Color.white); // wrap band
            }

            // scarf at the neck + two flowing tails
            Prim.Cube(h, new Vector3(0, 0.58f, 0), new Vector3(0.32f * w, 0.09f, 0.28f), scarf);
            GameObject tail = new GameObject("ScarfTail");
            tail.transform.SetParent(h, false);
            tail.transform.localPosition = new Vector3(0.1f, 0.56f, -0.14f);
            Prim.Cube(tail.transform, new Vector3(0, 0, -0.22f), new Vector3(0.09f, 0.04f, 0.46f), scarf);
            Prim.Cube(tail.transform, new Vector3(-0.1f, 0, -0.18f), new Vector3(0.09f, 0.04f, 0.4f), scarf * 0.85f);
            rig.scarfTail = tail.transform;

            // head
            Prim.Sphere(h, new Vector3(0, 0.80f, 0), new Vector3(0.30f, 0.32f, 0.30f), skin);
            // eyes
            Prim.Sphere(h, new Vector3(0.065f, 0.82f, 0.125f), new Vector3(0.05f, 0.06f, 0.03f), Color.white);
            Prim.Sphere(h, new Vector3(-0.065f, 0.82f, 0.125f), new Vector3(0.05f, 0.06f, 0.03f), Color.white);
            Prim.Sphere(h, new Vector3(0.065f, 0.82f, 0.14f), new Vector3(0.028f, 0.035f, 0.02f), Color.black);
            Prim.Sphere(h, new Vector3(-0.065f, 0.82f, 0.14f), new Vector3(0.028f, 0.035f, 0.02f), Color.black);
            // smile
            Prim.Cube(h, new Vector3(0, 0.73f, 0.14f), new Vector3(0.07f, 0.014f, 0.02f), new Color(0.6f, 0.2f, 0.2f));
            // earrings / gold detail
            Prim.Sphere(h, new Vector3(0.15f, 0.76f, 0), new Vector3(0.035f, 0.05f, 0.035f), Pal.Gold, 0.5f);
            Prim.Sphere(h, new Vector3(-0.15f, 0.76f, 0), new Vector3(0.035f, 0.05f, 0.035f), Pal.Gold, 0.5f);

            // hair
            Prim.Sphere(h, new Vector3(0, 0.855f, -0.025f), new Vector3(0.335f, 0.28f, 0.335f), hairC);
            if (female)
            {
                Prim.Cube(h, new Vector3(0, 0.88f, 0.1f), new Vector3(0.30f, 0.08f, 0.08f), hairC);   // fringe
                GameObject pony = new GameObject("Ponytail");
                pony.transform.SetParent(h, false);
                pony.transform.localPosition = new Vector3(0, 0.84f, -0.16f);
                Prim.Capsule(pony.transform, new Vector3(0, -0.14f, -0.06f), new Vector3(0.12f, 0.24f, 0.12f), hairC, 0f, new Vector3(-25, 0, 0));
                Prim.Sphere(pony.transform, new Vector3(0, 0, 0), new Vector3(0.07f, 0.07f, 0.07f), Pal.Gold, 0.4f);
                rig.hair = pony.transform;
            }
            else
            {
                Prim.Cyl(h, new Vector3(0, 0.89f, -0.01f), new Vector3(0.335f, 0.025f, 0.335f), scarf);
                GameObject band = new GameObject("BandTail");
                band.transform.SetParent(h, false);
                band.transform.localPosition = new Vector3(0, 0.86f, -0.17f);
                Prim.Cube(band.transform, new Vector3(0, 0, -0.12f), new Vector3(0.06f, 0.03f, 0.26f), scarf);
                rig.hair = band.transform;
            }

            // arms (pivot at shoulder)
            rig.lArm = BuildArm(h, -1, w, skin, top, female ? new Color(0.45f, 0.28f, 0.14f) : Pal.Gold, female);
            rig.rArm = BuildArm(h, 1, w, skin, top, female ? new Color(0.45f, 0.28f, 0.14f) : Pal.Gold, female);

            // legs (pivot at hip)
            rig.lLeg = BuildLeg(h, -1, pants, boots, female);
            rig.rLeg = BuildLeg(h, 1, pants, boots, female);

            rig.renderers = root.GetComponentsInChildren<Renderer>();
            return rig;
        }

        static Transform BuildArm(Transform hips, int side, float w, Color skin, Color sleeve, Color bracer, bool female)
        {
            GameObject pivot = new GameObject(side < 0 ? "ArmL" : "ArmR");
            pivot.transform.SetParent(hips, false);
            pivot.transform.localPosition = new Vector3(0.26f * w * side, 0.52f, 0);
            float t = female ? 1f : 1.2f;
            Prim.Capsule(pivot.transform, new Vector3(0, -0.17f, 0), new Vector3(0.12f * t, 0.19f, 0.12f * t), female ? sleeve : skin);
            Prim.Cyl(pivot.transform, new Vector3(0, -0.34f, 0), new Vector3(0.13f * t, 0.07f, 0.13f * t), bracer, 0.1f);
            Prim.Sphere(pivot.transform, new Vector3(0, -0.45f, 0), new Vector3(0.10f, 0.10f, 0.10f), skin);
            return pivot.transform;
        }

        static Transform BuildLeg(Transform hips, int side, Color pants, Color boots, bool female)
        {
            GameObject pivot = new GameObject(side < 0 ? "LegL" : "LegR");
            pivot.transform.SetParent(hips, false);
            pivot.transform.localPosition = new Vector3(0.10f * side, 0f, 0);
            float t = female ? 1f : 1.15f;
            Prim.Capsule(pivot.transform, new Vector3(0, -0.22f, 0), new Vector3(0.16f * t, 0.22f, 0.16f * t), pants);
            Prim.Capsule(pivot.transform, new Vector3(0, -0.58f, 0), new Vector3(0.14f * t, 0.19f, 0.14f * t), pants);
            Prim.Cyl(pivot.transform, new Vector3(0, -0.78f, 0), new Vector3(0.17f * t, 0.13f, 0.17f * t), boots);
            Prim.Cube(pivot.transform, new Vector3(0, -0.90f, 0.04f), new Vector3(0.15f * t, 0.12f, 0.26f), boots);
            return pivot.transform;
        }
    }

    /// <summary>Procedural animation for the primitive characters (Idle, Run, Jump, Slide, Turn, Collect, Hit/Fall).</summary>
    public class PlayerAnimator : MonoBehaviour
    {
        public enum AnimState { Idle, Run, Jump, Slide, Stumble, Fall }

        CharacterRig rig;
        AnimState state = AnimState.Idle;
        float t;
        float collectTimer;
        float stumbleTimer;
        float lean;
        float fallBlend;
        float leanTarget;

        public void SetRig(CharacterRig r)
        {
            rig = r;
            fallBlend = 0f;
        }

        public void SetState(AnimState s)
        {
            if (state == s) return;
            state = s;
            if (s == AnimState.Stumble) stumbleTimer = 0.6f;
            if (s != AnimState.Fall) fallBlend = 0f;
        }

        public AnimState State { get { return state; } }

        public void TriggerCollect() { collectTimer = 0.35f; }
        public void SetLean(float l) { leanTarget = l; }

        public void SetBlink(bool visible)
        {
            if (rig == null) return;
            for (int i = 0; i < rig.renderers.Length; i++)
                if (rig.renderers[i] != null) rig.renderers[i].enabled = visible;
        }

        void Update()
        {
            if (rig == null) return;
            float dt = Time.deltaTime;
            t += dt;
            lean = Mathf.Lerp(lean, leanTarget, 12f * dt);
            if (collectTimer > 0f) collectTimer -= dt;

            // defaults
            Quaternion lArm = Quaternion.identity, rArm = Quaternion.identity, lLeg = Quaternion.identity, rLeg = Quaternion.identity;
            Vector3 hipsPos = new Vector3(0, 0.95f, 0);
            Quaternion hipsRot = Quaternion.identity;
            Quaternion rootRot = Quaternion.Euler(0, 0, -lean * 14f);
            Vector3 rootPos = Vector3.zero;

            float runSpeed = GameManager.Instance != null ? Mathf.Clamp(GameManager.Instance.Speed / 12f, 0.8f, 2f) : 1f;

            switch (state)
            {
                case AnimState.Idle:
                    {
                        float b = Mathf.Sin(t * 2f) * 0.012f;
                        hipsPos.y += b;
                        lArm = Quaternion.Euler(Mathf.Sin(t * 2f) * 4f, 0, 4f);
                        rArm = Quaternion.Euler(-Mathf.Sin(t * 2f) * 4f, 0, -4f);
                        break;
                    }
                case AnimState.Run:
                    {
                        float f = t * 11f * runSpeed;
                        float s = Mathf.Sin(f);
                        hipsPos.y += Mathf.Abs(Mathf.Cos(f)) * 0.07f - 0.04f;
                        hipsRot = Quaternion.Euler(10f, Mathf.Sin(f) * 6f, 0);
                        lLeg = Quaternion.Euler(s * 55f, 0, 0);
                        rLeg = Quaternion.Euler(-s * 55f, 0, 0);
                        lArm = Quaternion.Euler(-s * 50f, 0, 6f);
                        rArm = Quaternion.Euler(s * 50f, 0, -6f);
                        break;
                    }
                case AnimState.Jump:
                    {
                        hipsRot = Quaternion.Euler(8f, 0, 0);
                        lLeg = Quaternion.Euler(-65f, 0, 0);
                        rLeg = Quaternion.Euler(25f, 0, 0);
                        lArm = Quaternion.Euler(-150f, 0, 10f);
                        rArm = Quaternion.Euler(-150f, 0, -10f);
                        break;
                    }
                case AnimState.Slide:
                    {
                        hipsPos = new Vector3(0, 0.42f, 0);
                        hipsRot = Quaternion.Euler(-78f, 0, 0);
                        lLeg = Quaternion.Euler(-8f, 0, 0);
                        rLeg = Quaternion.Euler(-14f, 0, 0);
                        lArm = Quaternion.Euler(-120f, 0, 15f);
                        rArm = Quaternion.Euler(-120f, 0, -15f);
                        break;
                    }
                case AnimState.Stumble:
                    {
                        stumbleTimer -= dt;
                        float k = Mathf.Clamp01(stumbleTimer / 0.6f);
                        hipsRot = Quaternion.Euler(-25f * k, 0, 0);
                        lArm = Quaternion.Euler(-100f * k, 0, 30f);
                        rArm = Quaternion.Euler(-80f * k, 0, -30f);
                        lLeg = Quaternion.Euler(30f * k, 0, 0);
                        rLeg = Quaternion.Euler(-30f * k, 0, 0);
                        if (stumbleTimer <= 0f) state = AnimState.Run;
                        break;
                    }
                case AnimState.Fall:
                    {
                        fallBlend = Mathf.MoveTowards(fallBlend, 1f, dt * 3.2f);
                        float k = fallBlend;
                        hipsPos = new Vector3(0, Mathf.Lerp(0.95f, 0.22f, k), 0);
                        hipsRot = Quaternion.Euler(-88f * k, 0, 0);
                        lLeg = Quaternion.Euler(-20f * k, 0, 10f * k);
                        rLeg = Quaternion.Euler(-10f * k, 0, -18f * k);
                        lArm = Quaternion.Euler(-60f * k, 0, 70f * k);
                        rArm = Quaternion.Euler(-40f * k, 0, -70f * k);
                        rootRot = Quaternion.identity;
                        break;
                    }
            }

            // Collect: right arm stretches forward and up to grab the relic
            if (collectTimer > 0f && state != AnimState.Fall && state != AnimState.Slide)
            {
                float k = Mathf.Sin((1f - collectTimer / 0.35f) * Mathf.PI);
                rArm = Quaternion.Slerp(rArm, Quaternion.Euler(-160f, 0, -10f), k);
            }

            rig.modelRoot.localRotation = rootRot;
            rig.modelRoot.localPosition = rootPos;
            rig.hips.localPosition = hipsPos;
            rig.hips.localRotation = hipsRot;
            rig.lArm.localRotation = lArm;
            rig.rArm.localRotation = rArm;
            rig.lLeg.localRotation = lLeg;
            rig.rLeg.localRotation = rLeg;

            // flowing hair/scarf
            float flow = (state == AnimState.Run || state == AnimState.Jump) ? 1f : 0.2f;
            if (rig.hair != null)
                rig.hair.localRotation = Quaternion.Euler(Mathf.Sin(t * 12f) * 12f * flow + 10f * flow, Mathf.Sin(t * 7f) * 10f * flow, 0);
            if (rig.scarfTail != null)
                rig.scarfTail.localRotation = Quaternion.Euler(Mathf.Sin(t * 14f) * 10f * flow - 10f * flow, Mathf.Sin(t * 9f) * 14f * flow, 0);
        }
    }
}
