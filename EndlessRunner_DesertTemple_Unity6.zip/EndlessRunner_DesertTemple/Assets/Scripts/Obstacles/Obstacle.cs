using UnityEngine;

namespace DesertTemple
{
    public enum ObstacleType
    {
        FallingBlock, Spikes, RollingBoulder, BrokenBridge, MovingWall,
        FireTrap, SandPit, StatueGuardian, SwingingAxe, CollapsingPillar
    }

    /// <summary>
    /// One obstacle instance. Visuals are built from primitives in Create(); behaviour (falling, rolling,
    /// swinging, collapsing...) runs in Update(). Obstacles are pooled and re-armed by the TrackManager.
    /// </summary>
    public class Obstacle : MonoBehaviour
    {
        public ObstacleType type;
        public int damage = 1;
        public bool fullWidth;                 // spans all lanes (bridge gap, swinging axe)
        public bool Smashed { get; private set; }

        Transform part;                        // moving part
        Transform spinPart;                    // boulder visual / sand swirl
        Transform[] flames;
        Collider[] colliders;
        Renderer[] renderers;

        Vector3 home;
        int lane;
        float t;
        float vel;
        float phase;
        float angle;
        bool triggered;
        float fallDir = 1f;

        public static string KeyFor(ObstacleType ty) { return "obs_" + ty; }

        // ------------------------------------------------------------------
        //  Creation
        // ------------------------------------------------------------------
        public static GameObject Create(ObstacleType ty)
        {
            GameObject root = new GameObject("Obstacle_" + ty);
            Obstacle o = root.AddComponent<Obstacle>();
            o.type = ty;
            Transform r = root.transform;
            Color stone = Pal.Sandstone;
            Color stoneDark = Pal.SandstoneDark;
            Color gold = Pal.Gold;
            Color teal = Pal.Teal;

            switch (ty)
            {
                case ObstacleType.FallingBlock:
                    {
                        // warning shadow on the floor + the hovering block
                        Prim.Cube(r, new Vector3(0, 0.03f, 0), new Vector3(2.3f, 0.04f, 2.3f), new Color(0.25f, 0.12f, 0.06f));
                        Prim.Cube(r, new Vector3(0, 0.05f, 0), new Vector3(1.6f, 0.04f, 1.6f), new Color(0.6f, 0.15f, 0.08f), 0.3f);
                        GameObject blk = new GameObject("Block");
                        blk.transform.SetParent(r, false);
                        blk.transform.localPosition = new Vector3(0, 7f, 0);
                        Prim.Cube(blk.transform, Vector3.zero, new Vector3(2f, 2f, 2f), stone);
                        Prim.Cube(blk.transform, new Vector3(0, 0, 1.01f), new Vector3(1.3f, 1.3f, 0.04f), stoneDark);
                        Prim.Cube(blk.transform, new Vector3(0, 0.25f, 1.04f), new Vector3(0.9f, 0.14f, 0.04f), teal, 0.5f);
                        Prim.Cube(blk.transform, new Vector3(0, -0.15f, 1.04f), new Vector3(0.5f, 0.14f, 0.04f), gold, 0.5f);
                        Prim.Cube(blk.transform, new Vector3(0, 1.02f, 0), new Vector3(2.1f, 0.12f, 2.1f), stoneDark);
                        Prim.Trigger(blk, Vector3.zero, new Vector3(2f, 2f, 2f));
                        o.part = blk.transform;
                        break;
                    }
                case ObstacleType.Spikes:
                    {
                        Prim.Cube(r, new Vector3(0, 0.06f, 0), new Vector3(2.3f, 0.12f, 2.3f), Pal.Brown);
                        for (int x = -1; x <= 1; x++)
                            for (int z = -1; z <= 1; z++)
                                Prim.Pyramid(r, new Vector3(x * 0.7f, 0.1f, z * 0.7f), new Vector3(0.34f, 0.8f, 0.34f), new Color(0.82f, 0.82f, 0.86f), 0.1f);
                        Prim.Trigger(root, new Vector3(0, 0.3f, 0), new Vector3(2.0f, 0.6f, 2.0f));
                        break;
                    }
                case ObstacleType.RollingBoulder:
                    {
                        GameObject holder = new GameObject("BoulderHolder");
                        holder.transform.SetParent(r, false);
                        holder.transform.localPosition = new Vector3(0, 1.2f, 0);
                        GameObject vis = new GameObject("BoulderVisual");
                        vis.transform.SetParent(holder.transform, false);
                        Prim.Sphere(vis.transform, Vector3.zero, new Vector3(2.4f, 2.4f, 2.4f), new Color(0.72f, 0.52f, 0.30f));
                        for (int i = 0; i < 7; i++)
                        {
                            Vector3 dir = Random.onUnitSphere;
                            Prim.Cube(vis.transform, dir * 1.18f, new Vector3(0.5f, 0.1f, 0.1f), stoneDark, 0f, Quaternion.LookRotation(dir).eulerAngles);
                        }
                        SphereCollider sc = holder.AddComponent<SphereCollider>();
                        sc.isTrigger = true;
                        sc.radius = 1.1f;
                        o.part = holder.transform;
                        o.spinPart = vis.transform;
                        break;
                    }
                case ObstacleType.BrokenBridge:
                    {
                        o.damage = 99;
                        o.fullWidth = true;
                        Prim.Cube(r, new Vector3(0, 0.04f, 0), new Vector3(9f, 0.06f, 4f), new Color(0.06f, 0.035f, 0.02f));
                        Prim.Cube(r, new Vector3(0, 0.07f, 0), new Vector3(8.6f, 0.02f, 3.4f), new Color(0.02f, 0.01f, 0.01f));
                        for (int i = 0; i < 9; i++)
                        {
                            float x = -4f + i * 1f;
                            float z = (i % 2 == 0) ? 2.05f : -2.05f;
                            Prim.Cube(r, new Vector3(x, 0.15f, z), new Vector3(0.7f, 0.3f, 0.4f), stone, 0f, new Vector3(0, Random.Range(-25f, 25f), 0));
                        }
                        Prim.Cube(r, new Vector3(-2.5f, 0.35f, 1.8f), new Vector3(1.4f, 0.12f, 0.4f), new Color(0.45f, 0.28f, 0.14f), 0f, new Vector3(25, 10, 0));
                        Prim.Cube(r, new Vector3(2.2f, 0.35f, -1.8f), new Vector3(1.4f, 0.12f, 0.4f), new Color(0.45f, 0.28f, 0.14f), 0f, new Vector3(-25, -10, 0));
                        Prim.Trigger(root, new Vector3(0, 0.3f, 0), new Vector3(9f, 0.6f, 3.4f));
                        break;
                    }
                case ObstacleType.MovingWall:
                    {
                        GameObject holder = new GameObject("WallHolder");
                        holder.transform.SetParent(r, false);
                        holder.transform.localPosition = new Vector3(0, 1.3f, 0);
                        Prim.Cube(holder.transform, Vector3.zero, new Vector3(2.3f, 2.6f, 0.6f), stoneDark);
                        Prim.Cube(holder.transform, new Vector3(0, 1.35f, 0), new Vector3(2.45f, 0.18f, 0.75f), gold, 0.3f);
                        for (int s = -1; s <= 1; s += 2)
                        {
                            float z = 0.31f * s;
                            Prim.Cube(holder.transform, new Vector3(0, 0.5f, z), new Vector3(1.4f, 0.12f, 0.03f), teal, 0.6f);
                            Prim.Cube(holder.transform, new Vector3(0, 0.1f, z), new Vector3(0.9f, 0.12f, 0.03f), gold, 0.6f);
                            Prim.Cube(holder.transform, new Vector3(0, -0.3f, z), new Vector3(1.2f, 0.12f, 0.03f), teal, 0.6f);
                            Prim.Cube(holder.transform, new Vector3(0, -0.8f, z), new Vector3(0.5f, 0.5f, 0.03f), gold, 0.5f);
                        }
                        Prim.Trigger(holder, Vector3.zero, new Vector3(2.3f, 2.6f, 0.6f));
                        o.part = holder.transform;
                        break;
                    }
                case ObstacleType.FireTrap:
                    {
                        Prim.Cube(r, new Vector3(0, 0.28f, 0), new Vector3(1.5f, 0.56f, 1.5f), stoneDark);
                        Prim.Cube(r, new Vector3(0, 0.58f, 0), new Vector3(1.7f, 0.1f, 1.7f), stone);
                        Prim.Cyl(r, new Vector3(0, 0.68f, 0), new Vector3(1.25f, 0.08f, 1.25f), Pal.DarkBrown);
                        Prim.Sphere(r, new Vector3(0, 0.76f, 0), new Vector3(1.0f, 0.25f, 1.0f), new Color(0.9f, 0.3f, 0.05f), 1.2f);
                        o.flames = new Transform[3];
                        float[] ys = { 0.95f, 1.25f, 1.55f };
                        float[] sc = { 0.85f, 0.6f, 0.35f };
                        Color[] cols = { new Color(1f, 0.45f, 0.05f), new Color(1f, 0.65f, 0.1f), new Color(1f, 0.9f, 0.4f) };
                        for (int i = 0; i < 3; i++)
                            o.flames[i] = Prim.Sphere(r, new Vector3(0, ys[i], 0), new Vector3(sc[i], sc[i] * 1.4f, sc[i]), cols[i], 1.6f).transform;
                        Prim.Trigger(root, new Vector3(0, 0.55f, 0), new Vector3(1.4f, 1.1f, 1.4f));
                        break;
                    }
                case ObstacleType.SandPit:
                    {
                        Prim.Cyl(r, new Vector3(0, 0.02f, 0), new Vector3(2.9f, 0.02f, 2.9f), stoneDark);
                        Prim.Cyl(r, new Vector3(0, 0.04f, 0), new Vector3(2.5f, 0.02f, 2.5f), new Color(0.22f, 0.13f, 0.06f));
                        GameObject sw = new GameObject("Swirl");
                        sw.transform.SetParent(r, false);
                        sw.transform.localPosition = new Vector3(0, 0.07f, 0);
                        for (int i = 0; i < 4; i++)
                            Prim.Cube(sw.transform, Vector3.zero, new Vector3(1.9f, 0.015f, 0.1f), new Color(0.6f, 0.42f, 0.2f), 0f, new Vector3(0, i * 45f, 0));
                        Prim.Cyl(r, new Vector3(0, 0.06f, 0), new Vector3(0.45f, 0.02f, 0.45f), Color.black);
                        o.spinPart = sw.transform;
                        Prim.Trigger(root, new Vector3(0, 0.25f, 0), new Vector3(2.0f, 0.5f, 2.0f));
                        break;
                    }
                case ObstacleType.StatueGuardian:
                    {
                        Color navy = new Color(0.14f, 0.26f, 0.38f);
                        Prim.Cube(r, new Vector3(0, 0.45f, 0), new Vector3(1.3f, 0.9f, 1.3f), navy);
                        Prim.Cube(r, new Vector3(0, 0.9f, 0), new Vector3(1.45f, 0.12f, 1.45f), gold, 0.4f);
                        Prim.Cube(r, new Vector3(0, 0.45f, 0.66f), new Vector3(0.7f, 0.12f, 0.03f), gold, 0.5f);
                        Prim.Cube(r, new Vector3(0, 1.7f, 0), new Vector3(0.85f, 1.45f, 0.5f), new Color(0.85f, 0.65f, 0.2f), 0.2f);
                        Prim.Cube(r, new Vector3(0, 2.2f, 0.26f), new Vector3(0.9f, 0.18f, 0.06f), teal, 0.6f);
                        Prim.Cube(r, new Vector3(0.55f, 1.65f, 0), new Vector3(0.2f, 1.1f, 0.24f), new Color(0.85f, 0.65f, 0.2f), 0.2f);
                        Prim.Cube(r, new Vector3(-0.55f, 1.65f, 0), new Vector3(0.2f, 1.1f, 0.24f), new Color(0.85f, 0.65f, 0.2f), 0.2f);
                        Prim.Cube(r, new Vector3(0, 2.7f, 0), new Vector3(0.52f, 0.5f, 0.55f), new Color(0.12f, 0.12f, 0.14f));
                        Prim.Cube(r, new Vector3(0, 2.62f, 0.4f), new Vector3(0.22f, 0.2f, 0.4f), new Color(0.12f, 0.12f, 0.14f));
                        Prim.Pyramid(r, new Vector3(0.16f, 2.9f, 0), new Vector3(0.16f, 0.5f, 0.12f), new Color(0.12f, 0.12f, 0.14f));
                        Prim.Pyramid(r, new Vector3(-0.16f, 2.9f, 0), new Vector3(0.16f, 0.5f, 0.12f), new Color(0.12f, 0.12f, 0.14f));
                        Prim.Sphere(r, new Vector3(0.12f, 2.76f, 0.29f), new Vector3(0.08f, 0.06f, 0.04f), teal, 2f);
                        Prim.Sphere(r, new Vector3(-0.12f, 2.76f, 0.29f), new Vector3(0.08f, 0.06f, 0.04f), teal, 2f);
                        Prim.Cube(r, new Vector3(0, 2.98f, 0), new Vector3(0.7f, 0.1f, 0.6f), gold, 0.4f);
                        Prim.Trigger(root, new Vector3(0, 1.6f, 0), new Vector3(1.4f, 3.2f, 1.2f));
                        break;
                    }
                case ObstacleType.SwingingAxe:
                    {
                        o.fullWidth = true;
                        Prim.Cube(r, new Vector3(-4.7f, 3.8f, 0), new Vector3(0.6f, 7.6f, 0.6f), stoneDark);
                        Prim.Cube(r, new Vector3(4.7f, 3.8f, 0), new Vector3(0.6f, 7.6f, 0.6f), stoneDark);
                        Prim.Cube(r, new Vector3(0, 7.5f, 0), new Vector3(10f, 0.5f, 0.7f), stone);
                        Prim.Cube(r, new Vector3(0, 7.8f, 0), new Vector3(10.2f, 0.12f, 0.8f), gold, 0.3f);
                        GameObject pivot = new GameObject("Pivot");
                        pivot.transform.SetParent(r, false);
                        pivot.transform.localPosition = new Vector3(0, 7.2f, 0);
                        Prim.Cyl(pivot.transform, new Vector3(0, -2.55f, 0), new Vector3(0.14f, 2.55f, 0.14f), new Color(0.35f, 0.22f, 0.12f));
                        GameObject head = new GameObject("AxeHead");
                        head.transform.SetParent(pivot.transform, false);
                        head.transform.localPosition = new Vector3(0, -5.3f, 0);
                        Prim.Cube(head.transform, new Vector3(0.45f, 0, 0), new Vector3(1.5f, 1.2f, 0.14f), new Color(0.78f, 0.78f, 0.84f), 0.15f);
                        Prim.Cube(head.transform, new Vector3(0.45f, 0, 0), new Vector3(1.3f, 0.9f, 0.18f), new Color(0.9f, 0.9f, 0.96f), 0.2f);
                        Prim.Cube(head.transform, new Vector3(-0.35f, 0, 0), new Vector3(0.35f, 0.5f, 0.3f), gold, 0.4f);
                        Prim.Trigger(head, new Vector3(0.2f, 0, 0), new Vector3(2.0f, 1.2f, 0.7f));
                        o.part = pivot.transform;
                        break;
                    }
                case ObstacleType.CollapsingPillar:
                    {
                        GameObject pivot = new GameObject("PillarPivot");
                        pivot.transform.SetParent(r, false);
                        pivot.transform.localPosition = new Vector3(0, 0.5f, 0);
                        Transform p = pivot.transform;
                        Prim.Cube(p, new Vector3(0, -0.35f, 0), new Vector3(1.5f, 0.3f, 1.5f), stoneDark);
                        Prim.Cyl(p, new Vector3(0, 1.6f, 0), new Vector3(1.0f, 1.95f, 1.0f), stone);
                        Prim.Cube(p, new Vector3(0, 3.6f, 0), new Vector3(1.5f, 0.3f, 1.5f), stoneDark);
                        Prim.Cube(p, new Vector3(0, 3.8f, 0), new Vector3(1.7f, 0.12f, 1.7f), gold, 0.3f);
                        Prim.Cube(p, new Vector3(0, 1.6f, 0.52f), new Vector3(0.25f, 2.6f, 0.04f), teal, 0.6f);
                        Prim.Cube(p, new Vector3(0, 1.0f, 0.55f), new Vector3(0.7f, 0.12f, 0.04f), gold, 0.6f);
                        Prim.Cube(p, new Vector3(0, 2.2f, 0.55f), new Vector3(0.7f, 0.12f, 0.04f), gold, 0.6f);
                        // cracks
                        Prim.Cube(p, new Vector3(0.2f, 0.6f, 0.5f), new Vector3(0.05f, 0.6f, 0.04f), Pal.DarkBrown, 0f, new Vector3(0, 0, 20));
                        Prim.Trigger(pivot, new Vector3(0, 1.6f, 0), new Vector3(1.3f, 4.3f, 1.3f));
                        o.part = p;
                        break;
                    }
            }

            o.colliders = root.GetComponentsInChildren<Collider>(true);
            o.renderers = root.GetComponentsInChildren<Renderer>(true);
            return root;
        }

        // ------------------------------------------------------------------
        //  Arming / resetting (called by the TrackManager after fetching from the pool)
        // ------------------------------------------------------------------
        public void Arm(Vector3 worldPos, int laneIndex)
        {
            transform.position = worldPos;
            transform.rotation = Quaternion.identity;
            home = worldPos;
            lane = laneIndex;
            Smashed = false;
            triggered = false;
            t = 0f;
            vel = 0f;
            angle = 0f;
            phase = Random.value * 6.28f;
            fallDir = laneIndex > 0 ? 1f : (laneIndex < 0 ? -1f : (Random.value > 0.5f ? 1f : -1f));

            for (int i = 0; i < colliders.Length; i++) if (colliders[i] != null) colliders[i].enabled = true;
            for (int i = 0; i < renderers.Length; i++) if (renderers[i] != null) renderers[i].enabled = true;

            switch (type)
            {
                case ObstacleType.FallingBlock: part.localPosition = new Vector3(0, 7f, 0); break;
                case ObstacleType.RollingBoulder: part.localPosition = new Vector3(0, 1.2f, 0); break;
                case ObstacleType.MovingWall: part.localPosition = new Vector3(0, 1.3f, 0); break;
                case ObstacleType.SwingingAxe: part.localRotation = Quaternion.Euler(0, 0, 38f * Mathf.Sin(phase)); break;
                case ObstacleType.CollapsingPillar: part.localRotation = Quaternion.identity; break;
            }
        }

        /// <summary>Destroys the obstacle visually (shield / invincibility hit).</summary>
        public void Smash()
        {
            Smashed = true;
            for (int i = 0; i < colliders.Length; i++) if (colliders[i] != null) colliders[i].enabled = false;
            for (int i = 0; i < renderers.Length; i++) if (renderers[i] != null) renderers[i].enabled = false;
        }

        // ------------------------------------------------------------------
        //  Behaviour
        // ------------------------------------------------------------------
        void Update()
        {
            GameManager gm = GameManager.Instance;
            if (gm == null || gm.State != GameState.Playing || Smashed) return;
            Transform pl = PlayerController.Instance.transform;
            float dz = home.z - pl.position.z;
            if (type != ObstacleType.RollingBoulder && (dz > 110f || dz < -40f)) return;

            float dt = Time.deltaTime;
            t += dt;

            switch (type)
            {
                case ObstacleType.FallingBlock:
                    {
                        if (!triggered && dz < gm.Speed * 0.9f + 6f) triggered = true;
                        if (triggered)
                        {
                            vel += -32f * dt;
                            Vector3 lp = part.localPosition;
                            lp.y += vel * dt;
                            if (lp.y <= 1f) { lp.y = 1f; vel = 0f; }
                            part.localPosition = lp;
                        }
                        break;
                    }
                case ObstacleType.RollingBoulder:
                    {
                        if (!triggered && dz < 60f && dz > 0f) triggered = true;
                        if (triggered)
                        {
                            Vector3 p = transform.position;
                            p.z -= 9f * dt;
                            transform.position = p;
                            spinPart.Rotate(-(9f / 1.2f) * Mathf.Rad2Deg * dt, 0f, 0f, Space.Self);
                        }
                        break;
                    }
                case ObstacleType.MovingWall:
                    {
                        float delta = lane == 1 ? -3f : (lane == -1 ? 3f : (Mathf.Sin(phase) > 0f ? 3f : -3f));
                        Vector3 p = transform.position;
                        p.x = home.x + delta * (0.5f + 0.5f * Mathf.Sin(t * 1.7f + phase));
                        transform.position = p;
                        break;
                    }
                case ObstacleType.FireTrap:
                    {
                        for (int i = 0; i < flames.Length; i++)
                        {
                            float k = 0.85f + 0.3f * Mathf.Sin(t * (13f + i * 3f) + i * 2f);
                            Vector3 s = flames[i].localScale;
                            s.y = Mathf.Abs(s.x) * 1.4f * k;
                            flames[i].localScale = s;
                        }
                        break;
                    }
                case ObstacleType.SandPit:
                    {
                        spinPart.Rotate(0f, 90f * dt, 0f, Space.Self);
                        break;
                    }
                case ObstacleType.SwingingAxe:
                    {
                        part.localRotation = Quaternion.Euler(0, 0, 38f * Mathf.Sin(t * 1.9f + phase));
                        break;
                    }
                case ObstacleType.CollapsingPillar:
                    {
                        if (!triggered && dz < gm.Speed * 1.0f + 8f) triggered = true;
                        if (triggered && angle < 90f)
                        {
                            angle = Mathf.Min(90f, angle + 110f * dt);
                            // Euler z = +90 tips the pillar toward -x, so the sign is inverted for the lane side
                            part.localRotation = Quaternion.Euler(0, 0, angle * fallDir);
                        }
                        break;
                    }
            }
        }
    }
}
