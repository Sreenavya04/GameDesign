using System.Collections.Generic;
using UnityEngine;

namespace DesertTemple
{
    public class ThemeDef
    {
        public string name;
        public Color floor, wall, ground, sky, fog, light, ambient, dune;
        public float groundTop = -0.15f;
        public float wallHeight = 2f;
        public float wallThick = 1f;
        public bool ceiling;
        public float lightIntensity = 1.2f;
    }

    /// <summary>Makes torch flames pulse.</summary>
    public class Flicker : MonoBehaviour
    {
        public Transform[] flames;
        Vector3[] baseScale;
        float seed;

        public void Init()
        {
            baseScale = new Vector3[flames.Length];
            for (int i = 0; i < flames.Length; i++) baseScale[i] = flames[i].localScale;
            seed = Random.value * 10f;
        }

        void Update()
        {
            if (baseScale == null) return;
            for (int i = 0; i < flames.Length; i++)
            {
                float k = 0.85f + 0.3f * Mathf.Sin(Time.time * (11f + i * 3f) + seed + i * 1.7f);
                flames[i].localScale = new Vector3(baseScale[i].x * (0.95f + 0.1f * k), baseScale[i].y * k, baseScale[i].z * (0.95f + 0.1f * k));
            }
        }
    }

    /// <summary>
    /// Endless track: a ring of pooled segments that are recycled in front of the player.
    /// Each segment gets a theme (6 environments, 600 m each), decorations, obstacles and collectibles.
    /// </summary>
    public class TrackManager : MonoBehaviour
    {
        public static TrackManager Instance;

        public const float SegLen = 30f;
        public const int SegCount = 9;
        public const int ThemeSegs = 20;                       // 20 * 30 m = 600 m per environment
        public const float ThemeLength = SegLen * ThemeSegs;

        public Camera cam;
        public Light sun;

        class Segment
        {
            public Transform root;
            public Renderer floor, ground, wallL, wallR, ceiling;
            public Renderer[] lines;
            public readonly List<GameObject> items = new List<GameObject>();
            public int index;
            public float startZ;
        }

        public static readonly ThemeDef[] Themes = new ThemeDef[]
        {
            new ThemeDef { name = "Temple Entrance", floor = new Color(0.88f, 0.70f, 0.44f), wall = new Color(0.76f, 0.55f, 0.32f), ground = new Color(0.93f, 0.78f, 0.50f),
                sky = new Color(0.55f, 0.78f, 0.95f), fog = new Color(0.96f, 0.84f, 0.62f), light = new Color(1f, 0.92f, 0.75f), ambient = new Color(0.75f, 0.62f, 0.48f),
                dune = new Color(0.93f, 0.76f, 0.48f), wallHeight = 2.4f, wallThick = 1f, lightIntensity = 1.25f },
            new ThemeDef { name = "Sandy Path", floor = new Color(0.92f, 0.74f, 0.46f), wall = new Color(0.82f, 0.62f, 0.38f), ground = new Color(0.95f, 0.80f, 0.52f),
                sky = new Color(0.60f, 0.82f, 0.96f), fog = new Color(0.98f, 0.87f, 0.65f), light = new Color(1f, 0.94f, 0.78f), ambient = new Color(0.78f, 0.66f, 0.50f),
                dune = new Color(0.95f, 0.80f, 0.52f), wallHeight = 0.7f, wallThick = 0.8f, lightIntensity = 1.3f },
            new ThemeDef { name = "Inner Temple Corridor", floor = new Color(0.62f, 0.45f, 0.27f), wall = new Color(0.55f, 0.38f, 0.22f), ground = new Color(0.30f, 0.20f, 0.12f),
                sky = new Color(0.10f, 0.06f, 0.04f), fog = new Color(0.14f, 0.09f, 0.05f), light = new Color(1f, 0.65f, 0.35f), ambient = new Color(0.45f, 0.32f, 0.22f),
                dune = new Color(0.4f, 0.3f, 0.2f), wallHeight = 9f, wallThick = 1.5f, ceiling = true, lightIntensity = 0.8f },
            new ThemeDef { name = "Broken Bridge", floor = new Color(0.76f, 0.56f, 0.35f), wall = new Color(0.40f, 0.25f, 0.12f), ground = new Color(0.20f, 0.10f, 0.07f),
                sky = new Color(0.88f, 0.62f, 0.42f), fog = new Color(0.92f, 0.68f, 0.48f), light = new Color(1f, 0.78f, 0.55f), ambient = new Color(0.65f, 0.48f, 0.38f),
                dune = new Color(0.60f, 0.36f, 0.22f), groundTop = -9f, wallHeight = 1f, wallThick = 0.25f, lightIntensity = 1.1f },
            new ThemeDef { name = "Oasis Ruins", floor = new Color(0.84f, 0.68f, 0.44f), wall = new Color(0.70f, 0.55f, 0.35f), ground = new Color(0.86f, 0.76f, 0.50f),
                sky = new Color(0.45f, 0.80f, 0.92f), fog = new Color(0.80f, 0.92f, 0.86f), light = new Color(1f, 0.96f, 0.82f), ambient = new Color(0.62f, 0.68f, 0.58f),
                dune = new Color(0.88f, 0.78f, 0.52f), wallHeight = 1.2f, wallThick = 0.9f, lightIntensity = 1.3f },
            new ThemeDef { name = "Sunset Dunes", floor = new Color(0.86f, 0.60f, 0.38f), wall = new Color(0.80f, 0.50f, 0.30f), ground = new Color(0.92f, 0.56f, 0.32f),
                sky = new Color(0.96f, 0.46f, 0.26f), fog = new Color(0.98f, 0.56f, 0.36f), light = new Color(1f, 0.58f, 0.32f), ambient = new Color(0.78f, 0.48f, 0.38f),
                dune = new Color(0.90f, 0.52f, 0.30f), wallHeight = 0.4f, wallThick = 0.8f, lightIntensity = 1.0f }
        };

        readonly List<Segment> segs = new List<Segment>();
        int nextIndex;
        int specialCooldown;

        // smoothed environment colours
        Color curSky, curFog, curLight, curAmbient;
        float curIntensity;
        bool envInit;

        public static int ThemeIndexAtDistance(float d)
        {
            return Mathf.FloorToInt(Mathf.Max(0f, d) / ThemeLength) % Themes.Length;
        }

        public static string ThemeNameAt(float d) { return Themes[ThemeIndexAtDistance(d)].name; }
        public static float ThemeProgressAt(float d) { return Mathf.Max(0f, d) % ThemeLength / ThemeLength; }

        void Awake()
        {
            Instance = this;
            for (int i = 0; i < SegCount; i++) segs.Add(BuildSegment(i));
        }

        // ------------------------------------------------------------------
        //  Segment construction
        // ------------------------------------------------------------------
        Segment BuildSegment(int i)
        {
            Segment s = new Segment();
            GameObject g = new GameObject("Segment_" + i);
            g.transform.SetParent(transform, false);
            s.root = g.transform;
            Transform r = s.root;

            s.floor = Prim.Cube(r, new Vector3(0, -0.5f, 0), new Vector3(9f, 1f, SegLen), Pal.Sand).GetComponent<Renderer>();
            s.ground = Prim.Cube(r, new Vector3(0, -0.65f, 0), new Vector3(180f, 1f, SegLen), Pal.Sand).GetComponent<Renderer>();
            s.wallL = Prim.Cube(r, new Vector3(-5f, 1f, 0), new Vector3(1f, 2f, SegLen), Pal.Sandstone).GetComponent<Renderer>();
            s.wallR = Prim.Cube(r, new Vector3(5f, 1f, 0), new Vector3(1f, 2f, SegLen), Pal.Sandstone).GetComponent<Renderer>();
            s.ceiling = Prim.Cube(r, new Vector3(0, 9.5f, 0), new Vector3(12f, 1f, SegLen), Pal.SandstoneDark).GetComponent<Renderer>();

            List<Renderer> lines = new List<Renderer>();
            lines.Add(Prim.Cube(r, new Vector3(-1.5f, 0.012f, 0), new Vector3(0.07f, 0.02f, SegLen), Pal.Sand).GetComponent<Renderer>());
            lines.Add(Prim.Cube(r, new Vector3(1.5f, 0.012f, 0), new Vector3(0.07f, 0.02f, SegLen), Pal.Sand).GetComponent<Renderer>());
            for (int k = 0; k < 6; k++)
                lines.Add(Prim.Cube(r, new Vector3(0, 0.012f, -SegLen / 2f + k * 5f + 0.05f), new Vector3(9f, 0.02f, 0.08f), Pal.Sand).GetComponent<Renderer>());
            s.lines = lines.ToArray();
            return s;
        }

        void ApplyTheme(Segment s, ThemeDef th)
        {
            s.floor.sharedMaterial = Mats.Get(th.floor);
            Color line = th.floor * 0.78f; line.a = 1f;
            for (int i = 0; i < s.lines.Length; i++) s.lines[i].sharedMaterial = Mats.Get(line);

            s.ground.sharedMaterial = Mats.Get(th.ground);
            s.ground.transform.localPosition = new Vector3(0, th.groundTop - 0.5f, 0);

            bool hasWall = th.wallHeight > 0.01f;
            s.wallL.gameObject.SetActive(hasWall);
            s.wallR.gameObject.SetActive(hasWall);
            if (hasWall)
            {
                float x = 4.5f + th.wallThick * 0.5f;
                Material wm = Mats.Get(th.wall);
                s.wallL.sharedMaterial = wm; s.wallR.sharedMaterial = wm;
                s.wallL.transform.localScale = new Vector3(th.wallThick, th.wallHeight, SegLen);
                s.wallR.transform.localScale = new Vector3(th.wallThick, th.wallHeight, SegLen);
                s.wallL.transform.localPosition = new Vector3(-x, th.wallHeight * 0.5f, 0);
                s.wallR.transform.localPosition = new Vector3(x, th.wallHeight * 0.5f, 0);
            }
            s.ceiling.gameObject.SetActive(th.ceiling);
            if (th.ceiling) s.ceiling.sharedMaterial = Mats.Get(th.wall * 0.8f);
        }

        // ------------------------------------------------------------------
        //  Reset / recycle
        // ------------------------------------------------------------------
        public void ResetTrack()
        {
            nextIndex = 0;
            specialCooldown = 0;
            for (int i = 0; i < segs.Count; i++) PlaceSegment(segs[i], nextIndex++);
            envInit = false;
        }

        void ReleaseItems(Segment s)
        {
            for (int i = 0; i < s.items.Count; i++) Pool.Release(s.items[i]);
            s.items.Clear();
        }

        void PlaceSegment(Segment s, int index)
        {
            ReleaseItems(s);
            s.index = index;
            s.startZ = (index - 1) * SegLen;
            s.root.position = new Vector3(0, 0, s.startZ + SegLen * 0.5f);

            int themeIdx = ThemeIndexAtDistance(s.startZ);
            ThemeDef th = Themes[themeIdx];
            ApplyTheme(s, th);
            BuildDecor(s, themeIdx, th);
            PopulateItems(s);
        }

        void Update()
        {
            if (PlayerController.Instance == null || segs.Count == 0) return;
            float pz = PlayerController.Instance.transform.position.z;

            // recycle the segment that fell far enough behind the player
            while (segs[0].startZ + SegLen < pz - 25f)
            {
                Segment first = segs[0];
                segs.RemoveAt(0);
                PlaceSegment(first, nextIndex++);
                segs.Add(first);
            }
            UpdateEnvironment();
        }

        void UpdateEnvironment()
        {
            float d = GameManager.Instance != null ? GameManager.Instance.Distance : 0f;
            ThemeDef th = Themes[ThemeIndexAtDistance(d + 60f)];
            if (!envInit)
            {
                curSky = th.sky; curFog = th.fog; curLight = th.light; curAmbient = th.ambient; curIntensity = th.lightIntensity;
                envInit = true;
            }
            float k = 1f - Mathf.Exp(-1.2f * Time.unscaledDeltaTime);
            curSky = Color.Lerp(curSky, th.sky, k);
            curFog = Color.Lerp(curFog, th.fog, k);
            curLight = Color.Lerp(curLight, th.light, k);
            curAmbient = Color.Lerp(curAmbient, th.ambient, k);
            curIntensity = Mathf.Lerp(curIntensity, th.lightIntensity, k);

            RenderSettings.fogColor = curFog;
            RenderSettings.ambientLight = curAmbient;
            if (cam != null) cam.backgroundColor = curFog;   // fog colour == background so distant geometry fades out
            if (sun != null) { sun.color = curLight; sun.intensity = curIntensity; }
        }

        // ------------------------------------------------------------------
        //  Decorations
        // ------------------------------------------------------------------
        GameObject Place(Segment s, string key, System.Func<GameObject> make, float x, float y, float z, float yaw, Vector3 scale)
        {
            GameObject g = Pool.Get(key, make);
            g.transform.SetParent(s.root, false);
            g.transform.localPosition = new Vector3(x, y, z);
            g.transform.localRotation = Quaternion.Euler(0, yaw, 0);
            g.transform.localScale = scale;
            s.items.Add(g);
            return g;
        }

        GameObject Place(Segment s, string key, System.Func<GameObject> make, float x, float y, float z, float yaw, float scale)
        {
            return Place(s, key, make, x, y, z, yaw, Vector3.one * scale);
        }

        static void Tint(GameObject g, Color c) { g.GetComponent<Renderer>().sharedMaterial = Mats.Get(c); }

        void BuildDecor(Segment s, int theme, ThemeDef th)
        {
            bool gate = s.startZ >= 0f && Mathf.RoundToInt(s.startZ) % Mathf.RoundToInt(ThemeLength) == 0;
            if (gate) Place(s, "dec_gate", MakeGate, 0, 0, -12f, 0, 1f);

            for (int side = -1; side <= 1; side += 2)
            {
                float yaw = side < 0 ? 90f : -90f;
                switch (theme)
                {
                    case 0: // Temple Entrance: pillars, torches, big statues, pyramids
                        Place(s, "dec_pillar", MakePillar, side * 7.6f, 0, -7f, 0, 1f);
                        Place(s, "dec_pillar", MakePillar, side * 7.6f, 0, 8f, 0, 1f);
                        Place(s, "dec_torch", MakeTorch, side * 6.0f, 0, 0.5f, 0, 1f);
                        if (s.index % 2 == 0) Place(s, "dec_statue", MakeStatue, side * 15f, 0, 0, side < 0 ? 180f : 180f, 1f);
                        if (Random.value < 0.5f) Place(s, "dec_palm", MakePalm, side * Random.Range(11f, 20f), 0, Random.Range(-12f, 12f), Random.Range(0f, 360f), Random.Range(0.9f, 1.2f));
                        if (s.index % 3 == 0) Tint(Place(s, "dec_pyramid", MakePyramidProp, side * 85f, 0, 0, 0, new Vector3(70f, 55f, 70f)), th.dune * 0.95f);
                        break;

                    case 1: // Sandy Path: palms, broken pillars, dunes
                        Place(s, "dec_palm", MakePalm, side * Random.Range(7.5f, 10f), 0, Random.Range(-12f, -2f), Random.Range(0f, 360f), Random.Range(0.9f, 1.3f));
                        Place(s, "dec_palm", MakePalm, side * Random.Range(10f, 18f), 0, Random.Range(2f, 12f), Random.Range(0f, 360f), Random.Range(0.9f, 1.3f));
                        if (Random.value < 0.6f) Place(s, "dec_brokenpillar", MakeBrokenPillar, side * Random.Range(6.8f, 9f), 0, Random.Range(-10f, 10f), Random.Range(0f, 360f), 1f);
                        Tint(Place(s, "dec_dune", MakeDune, side * Random.Range(34f, 48f), -3f, Random.Range(-6f, 6f), 0, new Vector3(34f, 9f, 26f)), th.dune);
                        if (s.index % 4 == 0) Tint(Place(s, "dec_pyramid", MakePyramidProp, side * 95f, 0, 0, 0, new Vector3(80f, 60f, 80f)), th.dune * 0.92f);
                        break;

                    case 2: // Inner Temple Corridor: pilasters + wall torches
                        Place(s, "dec_pilaster", MakePilaster, side * 4.6f, 0, -8f, side < 0 ? 0f : 180f, 1f);
                        Place(s, "dec_pilaster", MakePilaster, side * 4.6f, 0, 7f, side < 0 ? 0f : 180f, 1f);
                        Place(s, "dec_walltorch", MakeWallTorch, side * 4.15f, 3.3f, -0.5f, 0, 1f);
                        Place(s, "dec_walltorch", MakeWallTorch, side * 4.15f, 3.3f, 14f, 0, 1f);
                        break;

                    case 3: // Broken Bridge: canyon spires, broken pillars, floating rubble
                        Place(s, "dec_brokenpillar", MakeBrokenPillar, side * 6.0f, 0, Random.Range(-10f, 10f), Random.Range(0f, 360f), 1f);
                        Tint(Place(s, "dec_mountain", MakePyramidProp, side * Random.Range(16f, 30f), -9f, Random.Range(-8f, 8f), Random.Range(0f, 90f),
                            new Vector3(Random.Range(10f, 18f), Random.Range(20f, 34f), Random.Range(10f, 18f))), th.dune);
                        Place(s, "dec_rubble", MakeRubble, side * Random.Range(7f, 10f), Random.Range(-2f, 3f), Random.Range(-12f, 12f), Random.Range(0f, 360f), Random.Range(0.8f, 1.6f));
                        if (s.index % 2 == 0) Place(s, "dec_post", MakePost, side * 4.6f, 0, Random.Range(-10f, 10f), 0, 1f);
                        break;

                    case 4: // Oasis Ruins: water, palms, ruins
                        Place(s, "dec_water", MakeWater, side * 11f, -0.12f, 0, 0, new Vector3(9f, 0.25f, 22f));
                        Place(s, "dec_palm", MakePalm, side * Random.Range(6.8f, 8.2f), 0, Random.Range(-12f, 12f), Random.Range(0f, 360f), Random.Range(1f, 1.3f));
                        Place(s, "dec_palm", MakePalm, side * Random.Range(15.5f, 19f), 0, Random.Range(-12f, 12f), Random.Range(0f, 360f), Random.Range(1f, 1.4f));
                        Place(s, "dec_brokenpillar", MakeBrokenPillar, side * Random.Range(21f, 26f), 0, Random.Range(-10f, 10f), Random.Range(0f, 360f), 1.3f);
                        if (s.index % 2 == 1) Place(s, "dec_torch", MakeTorch, side * 5.9f, 0, 3f, 0, 1f);
                        break;

                    default: // Sunset Dunes: huge dunes + pyramids, few palms and torches
                        Tint(Place(s, "dec_dune", MakeDune, side * Random.Range(28f, 44f), -3.5f, Random.Range(-6f, 6f), 0, new Vector3(38f, 11f, 28f)), th.dune);
                        if (s.index % 2 == 0) Tint(Place(s, "dec_pyramid", MakePyramidProp, side * Random.Range(70f, 110f), 0, 0, 0, new Vector3(90f, 70f, 90f)), th.dune * 0.85f);
                        if (Random.value < 0.4f) Place(s, "dec_palm", MakePalm, side * Random.Range(8f, 14f), 0, Random.Range(-12f, 12f), Random.Range(0f, 360f), Random.Range(0.9f, 1.2f));
                        if (s.index % 3 == 0) Place(s, "dec_torch", MakeTorch, side * 5.6f, 0, 0, 0, 1f);
                        break;
                }
            }
        }

        // ---- prop builders (pooled, built once) --------------------------
        static GameObject MakePillar()
        {
            GameObject g = new GameObject("Pillar");
            Transform t = g.transform;
            Color st = Pal.Sandstone, sd = Pal.SandstoneDark;
            Prim.Cube(t, new Vector3(0, 0.25f, 0), new Vector3(1.9f, 0.5f, 1.9f), sd);
            Prim.Cyl(t, new Vector3(0, 3.1f, 0), new Vector3(1.25f, 2.6f, 1.25f), st);
            Prim.Cube(t, new Vector3(0, 5.95f, 0), new Vector3(1.9f, 0.5f, 1.9f), sd);
            Prim.Cube(t, new Vector3(0, 6.35f, 0), new Vector3(2.2f, 0.3f, 2.2f), st);
            Prim.Cyl(t, new Vector3(0, 5.4f, 0), new Vector3(1.32f, 0.08f, 1.32f), Pal.Gold, 0.3f);
            Prim.Cyl(t, new Vector3(0, 1.0f, 0), new Vector3(1.32f, 0.08f, 1.32f), Pal.Gold, 0.3f);
            for (int s = -1; s <= 1; s += 2)
            {
                Prim.Cube(t, new Vector3(0, 3.2f, 0.63f * s), new Vector3(0.22f, 3.2f, 0.04f), Pal.Teal, 0.5f);
                Prim.Cube(t, new Vector3(0.3f, 3.2f, 0.6f * s), new Vector3(0.12f, 2.4f, 0.04f), Pal.Gold, 0.4f);
                Prim.Cube(t, new Vector3(-0.3f, 3.2f, 0.6f * s), new Vector3(0.12f, 2.4f, 0.04f), Pal.Gold, 0.4f);
            }
            return g;
        }

        static GameObject MakeBrokenPillar()
        {
            GameObject g = new GameObject("BrokenPillar");
            Transform t = g.transform;
            Prim.Cube(t, new Vector3(0, 0.25f, 0), new Vector3(1.9f, 0.5f, 1.9f), Pal.SandstoneDark);
            Prim.Cyl(t, new Vector3(0, 1.7f, 0), new Vector3(1.25f, 1.2f, 1.25f), Pal.Sandstone);
            Prim.Cube(t, new Vector3(0.2f, 3.0f, 0), new Vector3(1.0f, 0.5f, 0.9f), Pal.Sandstone, 0f, new Vector3(10, 25, 20));
            Prim.Cube(t, new Vector3(1.6f, 0.4f, 0.9f), new Vector3(0.8f, 0.7f, 0.7f), Pal.SandstoneDark, 0f, new Vector3(0, 30, 0));
            Prim.Cube(t, new Vector3(-1.5f, 0.3f, -0.8f), new Vector3(1.0f, 0.5f, 0.6f), Pal.Sandstone, 0f, new Vector3(0, -40, 10));
            Prim.Cyl(t, new Vector3(2.2f, 0.5f, -1.2f), new Vector3(1.2f, 0.8f, 1.2f), Pal.Sandstone, 0f, new Vector3(0, 0, 80));
            Prim.Cube(t, new Vector3(0, 2.0f, 0.63f), new Vector3(0.22f, 1.5f, 0.04f), Pal.Teal, 0.5f);
            return g;
        }

        static GameObject MakePilaster()
        {
            GameObject g = new GameObject("Pilaster");
            Transform t = g.transform;
            Prim.Cube(t, new Vector3(0, 4.3f, 0), new Vector3(0.7f, 8.6f, 1.8f), Pal.Sandstone);
            Prim.Cube(t, new Vector3(0.38f, 4.3f, 0), new Vector3(0.08f, 8.0f, 0.5f), Pal.Teal, 0.5f);
            Prim.Cube(t, new Vector3(0.38f, 4.3f, 0.6f), new Vector3(0.08f, 7.0f, 0.1f), Pal.Gold, 0.4f);
            Prim.Cube(t, new Vector3(0.38f, 4.3f, -0.6f), new Vector3(0.08f, 7.0f, 0.1f), Pal.Gold, 0.4f);
            Prim.Cube(t, new Vector3(0.2f, 0.4f, 0), new Vector3(1.0f, 0.8f, 2.1f), Pal.SandstoneDark);
            Prim.Cube(t, new Vector3(0.2f, 8.3f, 0), new Vector3(1.0f, 0.5f, 2.1f), Pal.SandstoneDark);
            return g;
        }

        static GameObject MakeTorch()
        {
            GameObject g = new GameObject("Torch");
            Transform t = g.transform;
            Prim.Cube(t, new Vector3(0, 0.6f, 0), new Vector3(0.7f, 1.2f, 0.7f), Pal.SandstoneDark);
            Prim.Cyl(t, new Vector3(0, 1.3f, 0), new Vector3(1.0f, 0.1f, 1.0f), Pal.Brown);
            Prim.Cyl(t, new Vector3(0, 1.45f, 0), new Vector3(0.8f, 0.14f, 0.8f), Pal.Gold, 0.4f);
            AddFlames(g, new Vector3(0, 1.6f, 0), 1f);
            return g;
        }

        static GameObject MakeWallTorch()
        {
            GameObject g = new GameObject("WallTorch");
            Transform t = g.transform;
            Prim.Cube(t, new Vector3(0, -0.5f, 0), new Vector3(0.5f, 1.0f, 0.5f), Pal.SandstoneDark);
            Prim.Cyl(t, new Vector3(0, 0.15f, 0), new Vector3(0.8f, 0.1f, 0.8f), Pal.Gold, 0.4f);
            AddFlames(g, new Vector3(0, 0.3f, 0), 1f);
            return g;
        }

        static void AddFlames(GameObject g, Vector3 basePos, float scale)
        {
            Flicker f = g.AddComponent<Flicker>();
            f.flames = new Transform[3];
            float[] ys = { 0.1f, 0.38f, 0.65f };
            float[] sc = { 0.6f, 0.42f, 0.24f };
            Color[] cols = { new Color(1f, 0.42f, 0.05f), new Color(1f, 0.65f, 0.1f), new Color(1f, 0.92f, 0.45f) };
            for (int i = 0; i < 3; i++)
                f.flames[i] = Prim.Sphere(g.transform, basePos + new Vector3(0, ys[i] * scale, 0), new Vector3(sc[i], sc[i] * 1.5f, sc[i]) * scale, cols[i], 1.8f).transform;
            f.Init();
        }

        static GameObject MakePost()
        {
            GameObject g = new GameObject("Post");
            Prim.Cube(g.transform, new Vector3(0, 0.7f, 0), new Vector3(0.3f, 1.4f, 0.3f), new Color(0.4f, 0.25f, 0.12f));
            Prim.Cube(g.transform, new Vector3(0, 1.45f, 0), new Vector3(0.5f, 0.12f, 0.5f), Pal.Gold, 0.3f);
            return g;
        }

        static GameObject MakeStatue()
        {
            GameObject g = new GameObject("Statue");
            Transform t = g.transform;
            Color st = Pal.Sandstone, sd = Pal.SandstoneDark;
            Prim.Cube(t, new Vector3(0, 0.8f, 0), new Vector3(5.0f, 1.6f, 5.0f), sd);
            Prim.Cube(t, new Vector3(0, 3.0f, -0.4f), new Vector3(2.8f, 3.2f, 1.6f), st);
            Prim.Cube(t, new Vector3(0, 2.2f, 0.9f), new Vector3(2.8f, 1.2f, 2.2f), st);                 // lap
            Prim.Cube(t, new Vector3(1.0f, 2.95f, 0.9f), new Vector3(0.6f, 0.5f, 1.8f), st);             // arms on knees
            Prim.Cube(t, new Vector3(-1.0f, 2.95f, 0.9f), new Vector3(0.6f, 0.5f, 1.8f), st);
            Prim.Cube(t, new Vector3(1.6f, 4.0f, -0.4f), new Vector3(0.6f, 1.6f, 0.8f), st);
            Prim.Cube(t, new Vector3(-1.6f, 4.0f, -0.4f), new Vector3(0.6f, 1.6f, 0.8f), st);
            Prim.Cube(t, new Vector3(0, 5.5f, -0.4f), new Vector3(1.3f, 1.3f, 1.3f), st);                // head
            Prim.Cube(t, new Vector3(0, 5.6f, -0.9f), new Vector3(2.0f, 1.9f, 0.8f), Pal.Gold, 0.35f);   // nemes
            Prim.Cube(t, new Vector3(0, 5.55f, 0.28f), new Vector3(1.4f, 0.2f, 0.06f), Pal.Teal, 0.6f);
            Prim.Cube(t, new Vector3(0, 6.4f, -0.5f), new Vector3(1.6f, 0.3f, 1.6f), Pal.Gold, 0.35f);
            Prim.Cube(t, new Vector3(0, 4.55f, 0.35f), new Vector3(0.2f, 0.8f, 0.2f), Pal.Teal, 0.4f);    // beard
            Prim.Cube(t, new Vector3(0, 3.7f, 0.42f), new Vector3(1.8f, 0.3f, 0.06f), Pal.Gold, 0.5f);    // collar
            Prim.Cube(t, new Vector3(0, 3.0f, 0.42f), new Vector3(0.9f, 0.14f, 0.06f), Pal.Teal, 0.5f);
            return g;
        }

        static GameObject MakePalm()
        {
            GameObject g = new GameObject("Palm");
            Transform t = g.transform;
            Color trunk = new Color(0.55f, 0.38f, 0.2f);
            for (int i = 0; i < 4; i++)
                Prim.Cyl(t, new Vector3(0.15f * i, 1.1f + 2.0f * i, 0), new Vector3(0.45f - i * 0.04f, 1.1f, 0.45f - i * 0.04f), trunk, 0f, new Vector3(0, 0, -4f * i));
            GameObject crown = new GameObject("Crown");
            crown.transform.SetParent(t, false);
            crown.transform.localPosition = new Vector3(0.5f, 8.1f, 0);
            for (int i = 0; i < 7; i++)
            {
                GameObject holder = new GameObject("Leaf");
                holder.transform.SetParent(crown.transform, false);
                holder.transform.localRotation = Quaternion.Euler(0, i * (360f / 7f), 0);
                Prim.Cube(holder.transform, new Vector3(0, -0.35f, 1.5f), new Vector3(0.7f, 0.06f, 3.2f), Pal.Green, 0f, new Vector3(28, 0, 0));
                Prim.Cube(holder.transform, new Vector3(0, -0.28f, 1.5f), new Vector3(0.12f, 0.08f, 3.1f), new Color(0.12f, 0.38f, 0.14f), 0f, new Vector3(28, 0, 0));
            }
            Prim.Sphere(crown.transform, new Vector3(0.18f, -0.25f, 0.1f), new Vector3(0.35f, 0.35f, 0.35f), new Color(0.4f, 0.26f, 0.12f));
            Prim.Sphere(crown.transform, new Vector3(-0.18f, -0.25f, -0.1f), new Vector3(0.35f, 0.35f, 0.35f), new Color(0.4f, 0.26f, 0.12f));
            return g;
        }

        static GameObject MakeDune()
        {
            GameObject g = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            Destroy(g.GetComponent<Collider>());
            g.GetComponent<Renderer>().shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            g.name = "Dune";
            return g;
        }

        static GameObject MakePyramidProp()
        {
            GameObject g = new GameObject("PyramidProp");
            g.AddComponent<MeshFilter>().sharedMesh = MeshLib.Pyramid();
            MeshRenderer r = g.AddComponent<MeshRenderer>();
            r.sharedMaterial = Mats.Get(Pal.Sand);
            r.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            return g;
        }

        static GameObject MakeWater()
        {
            GameObject g = GameObject.CreatePrimitive(PrimitiveType.Cube);
            Destroy(g.GetComponent<Collider>());
            g.GetComponent<Renderer>().sharedMaterial = Mats.Get(Pal.Water, 0.5f);
            g.GetComponent<Renderer>().shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            g.name = "Water";
            return g;
        }

        static GameObject MakeRubble()
        {
            GameObject g = new GameObject("Rubble");
            Transform t = g.transform;
            Prim.Cube(t, Vector3.zero, new Vector3(2.0f, 1.2f, 1.6f), Pal.Sandstone, 0f, new Vector3(12, 20, 8));
            Prim.Cube(t, new Vector3(1.4f, 0.6f, 0.4f), new Vector3(1.0f, 0.8f, 1.0f), Pal.SandstoneDark, 0f, new Vector3(0, 40, 20));
            Prim.Cube(t, new Vector3(-1.1f, -0.5f, -0.3f), new Vector3(0.9f, 0.7f, 0.9f), Pal.Sandstone, 0f, new Vector3(30, 0, 10));
            return g;
        }

        static GameObject MakeGate()
        {
            GameObject g = new GameObject("TempleGate");
            Transform t = g.transform;
            for (int s = -1; s <= 1; s += 2)
            {
                Prim.Cube(t, new Vector3(5.9f * s, 5.2f, 0), new Vector3(1.8f, 10.4f, 2.2f), Pal.Sandstone);
                Prim.Cube(t, new Vector3(5.9f * s, 0.4f, 0), new Vector3(2.3f, 0.8f, 2.7f), Pal.SandstoneDark);
                Prim.Cube(t, new Vector3(5.0f * s, 5.0f, -1.12f), new Vector3(0.18f, 8.4f, 0.05f), Pal.Teal, 0.6f);
                Prim.Cube(t, new Vector3(5.5f * s, 7.0f, -1.12f), new Vector3(0.9f, 0.18f, 0.05f), Pal.Gold, 0.6f);
                Prim.Cube(t, new Vector3(5.5f * s, 4.0f, -1.12f), new Vector3(0.9f, 0.18f, 0.05f), Pal.Gold, 0.6f);
                // flame bowls on top
                Prim.Cyl(t, new Vector3(5.9f * s, 10.7f, 0), new Vector3(1.4f, 0.2f, 1.4f), Pal.Gold, 0.4f);
                AddFlames(g, new Vector3(5.9f * s, 10.8f, 0), 1.3f);
            }
            Prim.Cube(t, new Vector3(0, 10.0f, 0), new Vector3(14f, 1.8f, 2.4f), Pal.Sandstone);
            Prim.Cube(t, new Vector3(0, 11.0f, 0), new Vector3(14.6f, 0.3f, 2.8f), Pal.SandstoneDark);
            Prim.Cube(t, new Vector3(0, 10.0f, -1.22f), new Vector3(12f, 0.3f, 0.05f), Pal.Teal, 0.6f);
            // winged sun disc
            Prim.Cyl(t, new Vector3(0, 10.0f, -1.3f), new Vector3(1.3f, 0.06f, 1.3f), Pal.Gold, 0.9f, new Vector3(90, 0, 0));
            Prim.Cube(t, new Vector3(2.2f, 10.0f, -1.3f), new Vector3(3.0f, 0.25f, 0.05f), Pal.Gold, 0.7f);
            Prim.Cube(t, new Vector3(-2.2f, 10.0f, -1.3f), new Vector3(3.0f, 0.25f, 0.05f), Pal.Gold, 0.7f);
            return g;
        }

        // ------------------------------------------------------------------
        //  Obstacle and collectible spawning
        // ------------------------------------------------------------------
        static readonly ObstacleType[] LaneObstacles =
        {
            ObstacleType.FallingBlock, ObstacleType.Spikes, ObstacleType.RollingBoulder, ObstacleType.MovingWall,
            ObstacleType.FireTrap, ObstacleType.SandPit, ObstacleType.StatueGuardian, ObstacleType.CollapsingPillar
        };

        static readonly CollectibleType[] Relics =
            { CollectibleType.Ankh, CollectibleType.Gem, CollectibleType.Scarab, CollectibleType.Idol };

        static readonly CollectibleType[] Specials =
        {
            CollectibleType.SpeedBoost, CollectibleType.Shield, CollectibleType.Magnet, CollectibleType.Invincibility,
            CollectibleType.Multiplier, CollectibleType.Hourglass, CollectibleType.SunOrb, CollectibleType.PalmLeaf, CollectibleType.Scroll
        };

        void PopulateItems(Segment s)
        {
            if (s.index < 3) return;                       // keep the first ~60 m clear
            float diff = GameManager.DifficultyAt(Mathf.Max(0f, s.startZ));
            float[] rowZ = { 5f, 14f, 23f };
            if (specialCooldown > 0) specialCooldown--;

            for (int r = 0; r < rowZ.Length; r++)
            {
                float z = s.startZ + rowZ[r] + Random.Range(-1.5f, 1.5f);
                if (Random.value < Mathf.Lerp(0.55f, 0.9f, diff)) SpawnObstacleRow(s, z, diff);
                else SpawnCollectibleRow(s, z);
            }
        }

        GameObject SpawnObstacle(Segment s, ObstacleType ty, int lane, float z)
        {
            GameObject go = Pool.Get(Obstacle.KeyFor(ty), () => Obstacle.Create(ty));
            go.transform.SetParent(s.root, false);
            go.GetComponent<Obstacle>().Arm(new Vector3(lane * PlayerController.LaneWidth, 0f, z), lane);
            s.items.Add(go);
            return go;
        }

        GameObject SpawnCollectible(Segment s, CollectibleType ty, float x, float y, float z)
        {
            GameObject go = Pool.Get(Collectible.KeyFor(ty), () => Collectible.Create(ty));
            go.transform.SetParent(s.root, false);
            go.transform.position = new Vector3(x, y, z);
            go.transform.rotation = Quaternion.identity;
            go.GetComponent<Collectible>().ResetState();
            s.items.Add(go);
            return go;
        }

        void CoinLine(Segment s, int lane, float z, int count, float y)
        {
            for (int i = 0; i < count; i++)
                SpawnCollectible(s, CollectibleType.Coin, lane * PlayerController.LaneWidth, y, z + i * 1.8f);
        }

        void CoinArc(Segment s, int lane, float zCenter, int count, float baseY, float peak)
        {
            float span = (count - 1) * 1.4f;
            for (int i = 0; i < count; i++)
            {
                float k = count == 1 ? 0.5f : i / (float)(count - 1);
                float y = baseY + Mathf.Sin(k * Mathf.PI) * (peak - baseY);
                SpawnCollectible(s, CollectibleType.Coin, lane * PlayerController.LaneWidth, y, zCenter - span * 0.5f + i * 1.4f);
            }
        }

        void SpawnObstacleRow(Segment s, float z, float diff)
        {
            float roll = Random.value;
            if (roll < 0.14f)
            {
                // full-width obstacles
                if (Random.value < 0.55f)
                {
                    SpawnObstacle(s, ObstacleType.BrokenBridge, 0, z);
                    for (int l = -1; l <= 1; l++) CoinArc(s, l, z, 5, 1.1f, 2.6f);     // coins show the jump arc
                }
                else
                {
                    SpawnObstacle(s, ObstacleType.SwingingAxe, 0, z);
                }
                return;
            }

            int laneA = Random.Range(-1, 2);
            ObstacleType a = LaneObstacles[Random.Range(0, LaneObstacles.Length)];
            SpawnObstacle(s, a, laneA, z);

            int laneB = 99;
            bool second = a != ObstacleType.MovingWall && Random.value < Mathf.Lerp(0.08f, 0.55f, diff);
            if (second)
            {
                do { laneB = Random.Range(-1, 2); } while (laneB == laneA);
                ObstacleType b = LaneObstacles[Random.Range(0, LaneObstacles.Length)];
                if (b == ObstacleType.MovingWall) b = ObstacleType.Spikes;
                SpawnObstacle(s, b, laneB, z + Random.Range(-1f, 1f));
            }

            // reward the free lane(s)
            for (int l = -1; l <= 1; l++)
            {
                if (l == laneA || l == laneB) continue;
                if (Random.value < 0.7f) CoinLine(s, l, z - 3f, 4, 1.0f);
            }
        }

        void SpawnCollectibleRow(Segment s, float z)
        {
            int lane = Random.Range(-1, 2);
            float roll = Random.value;
            if (roll < 0.50f) CoinLine(s, lane, z - 4f, 6, 1.0f);
            else if (roll < 0.68f)
            {
                CollectibleType rel = Relics[Random.Range(0, Relics.Length)];
                for (int i = 0; i < 3; i++) SpawnCollectible(s, rel, lane * PlayerController.LaneWidth, 1.1f, z - 2f + i * 2.2f);
            }
            else if (roll < 0.82f) CoinArc(s, lane, z, 6, 1.0f, 2.7f);
            else if (roll < 0.92f)
            {
                for (int l = -1; l <= 1; l++) CoinLine(s, l, z - 2f, 3, 1.0f);
            }
            else if (specialCooldown <= 0)
            {
                CollectibleType sp = Specials[Random.Range(0, Specials.Length)];
                SpawnCollectible(s, sp, lane * PlayerController.LaneWidth, 1.3f, z);
                specialCooldown = 4;
            }
            else CoinLine(s, lane, z - 4f, 5, 1.0f);
        }
    }
}
