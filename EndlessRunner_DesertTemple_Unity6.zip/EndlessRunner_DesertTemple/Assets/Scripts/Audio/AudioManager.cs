using UnityEngine;

namespace DesertTemple
{
    /// <summary>
    /// Generates all sound effects and a looping desert-style music track procedurally,
    /// so the project needs no audio files. Music/SFX can be toggled (saved in PlayerPrefs).
    /// </summary>
    public class AudioManager : MonoBehaviour
    {
        public static AudioManager Instance;

        const int Rate = 22050;
        AudioSource music, sfx;
        AudioClip coin, jump, slide, hit, power, swish, click, gameOver, musicClip;

        public bool MusicOn { get; private set; }
        public bool SfxOn { get; private set; }

        void Awake()
        {
            Instance = this;
            MusicOn = PlayerPrefs.GetInt("DT_Music", 1) == 1;
            SfxOn = PlayerPrefs.GetInt("DT_Sfx", 1) == 1;

            music = gameObject.AddComponent<AudioSource>();
            music.loop = true;
            music.playOnAwake = false;
            music.volume = 0.35f;
            sfx = gameObject.AddComponent<AudioSource>();
            sfx.playOnAwake = false;
            sfx.volume = 0.7f;

            coin = Tone("coin", 0.16f, t => (Mathf.Sin(2f * Mathf.PI * (t < 0.06f ? 988f : 1319f) * t)) * Env(t, 0.16f, 20f), 0.5f);
            jump = Tone("jump", 0.22f, t => Mathf.Sin(2f * Mathf.PI * (300f + 900f * t) * t) * Env(t, 0.22f, 8f), 0.5f);
            swish = Tone("swish", 0.12f, t => (Noise(t) * 0.6f) * Env(t, 0.12f, 14f), 0.35f);
            slide = Tone("slide", 0.35f, t => Noise(t) * Mathf.Sin(t * 30f) * 0.5f * Env(t, 0.35f, 5f), 0.5f);
            hit = Tone("hit", 0.4f, t => (Noise(t) * 0.6f + Mathf.Sin(2f * Mathf.PI * 90f * t) * 0.8f) * Env(t, 0.4f, 8f), 0.8f);
            power = Tone("power", 0.5f, t =>
            {
                float f = t < 0.12f ? 523f : (t < 0.24f ? 659f : (t < 0.36f ? 784f : 1047f));
                return Mathf.Sin(2f * Mathf.PI * f * t) * Env(t, 0.5f, 4f);
            }, 0.5f);
            click = Tone("click", 0.08f, t => Mathf.Sin(2f * Mathf.PI * 700f * t) * Env(t, 0.08f, 30f), 0.5f);
            gameOver = Tone("gameover", 0.9f, t =>
            {
                float f = t < 0.3f ? 392f : (t < 0.6f ? 330f : 262f);
                return Mathf.Sin(2f * Mathf.PI * f * t) * Env(t, 0.9f, 3f);
            }, 0.6f);

            musicClip = BuildMusic();
        }

        void Start() { ApplyMusic(); }

        // ------------------------------------------------------------------
        //  Public API
        // ------------------------------------------------------------------
        public void PlayCoin() { Play(coin); }
        public void PlayJump() { Play(jump); }
        public void PlaySlide() { Play(slide); }
        public void PlayHit() { Play(hit); }
        public void PlayPowerUp() { Play(power); }
        public void PlaySwish() { Play(swish); }
        public void PlayClick() { Play(click); }
        public void PlayGameOver() { Play(gameOver); }

        public void SetMusic(bool on)
        {
            MusicOn = on;
            PlayerPrefs.SetInt("DT_Music", on ? 1 : 0);
            ApplyMusic();
        }

        public void SetSfx(bool on)
        {
            SfxOn = on;
            PlayerPrefs.SetInt("DT_Sfx", on ? 1 : 0);
        }

        void ApplyMusic()
        {
            if (MusicOn)
            {
                if (!music.isPlaying) { music.clip = musicClip; music.Play(); }
            }
            else music.Stop();
        }

        void Play(AudioClip c)
        {
            if (!SfxOn || c == null) return;
            sfx.PlayOneShot(c);
        }

        // ------------------------------------------------------------------
        //  Procedural synthesis
        // ------------------------------------------------------------------
        static float Env(float t, float len, float decay)
        {
            float attack = Mathf.Clamp01(t / 0.005f);
            return attack * Mathf.Exp(-decay * t) * Mathf.Clamp01((len - t) / 0.02f);
        }

        static float Noise(float t)
        {
            // deterministic pseudo-noise (thread-safe, no allocations)
            float x = Mathf.Sin(t * 12345.6789f) * 43758.5453f;
            return (x - Mathf.Floor(x)) * 2f - 1f;
        }

        static AudioClip Tone(string name, float seconds, System.Func<float, float> f, float gain)
        {
            int n = Mathf.CeilToInt(seconds * Rate);
            float[] data = new float[n];
            for (int i = 0; i < n; i++) data[i] = Mathf.Clamp(f(i / (float)Rate) * gain, -1f, 1f);
            AudioClip c = AudioClip.Create(name, n, 1, Rate, false);
            c.SetData(data, 0);
            return c;
        }

        /// <summary>16 second loop in D phrygian dominant: drone + pulse + plucked melody.</summary>
        static AudioClip BuildMusic()
        {
            const float bpm = 112f;
            float step = 60f / bpm / 2f;                   // eighth notes
            const int steps = 64;
            float seconds = steps * step;
            int n = Mathf.CeilToInt(seconds * Rate);
            float[] data = new float[n];

            // D phrygian dominant: D Eb F# G A Bb C (semitones from D)
            int[] scale = { 0, 1, 4, 5, 7, 8, 10, 12, 13, 16, 17, 19 };
            int[] melody = { 0, 2, 3, 4, 3, 2, 1, 0,   4, 5, 6, 5, 4, 3, 2, 1,
                             0, 2, 3, 4, 7, 6, 5, 4,   3, 4, 3, 2, 1, 2, 0, 0,
                             7, 8, 9, 8, 7, 6, 5, 4,   5, 6, 5, 4, 3, 2, 1, 0,
                             0, 2, 4, 5, 4, 2, 1, 0,   1, 2, 3, 2, 1, 0, 0, 0 };
            float rootFreq = 146.83f;                      // D3

            for (int i = 0; i < n; i++)
            {
                float t = i / (float)Rate;
                int stepIdx = Mathf.Min(steps - 1, Mathf.FloorToInt(t / step));
                float tt = t - stepIdx * step;               // time inside the step
                float v = 0f;

                // plucked melody
                int deg = scale[Mathf.Clamp(melody[stepIdx], 0, scale.Length - 1)];
                float f = rootFreq * 2f * Mathf.Pow(2f, deg / 12f);
                float pluck = Mathf.Exp(-6f * tt) * Mathf.Clamp01(tt / 0.004f);
                v += (Mathf.Sin(2f * Mathf.PI * f * tt + stepIdx) * 0.6f + Mathf.Sin(4f * Mathf.PI * f * tt) * 0.2f) * pluck * 0.35f;

                // drone with slow tremolo
                float drone = Mathf.Sin(2f * Mathf.PI * (rootFreq * 0.5f) * t) * (0.7f + 0.3f * Mathf.Sin(t * 1.5f));
                v += drone * 0.12f;

                // drum on the beat (every 2 steps) with an off-beat tick
                float beatT = Mathf.Repeat(t, step * 2f);
                float kick = Mathf.Sin(2f * Mathf.PI * (60f + 90f * Mathf.Exp(-30f * beatT)) * beatT) * Mathf.Exp(-12f * beatT);
                v += kick * 0.35f;
                float offT = Mathf.Repeat(t + step, step * 2f);
                float x = Mathf.Sin(t * 91234.5f) * 43758.5453f;
                float nz = (x - Mathf.Floor(x)) * 2f - 1f;
                v += nz * Mathf.Exp(-60f * offT) * 0.07f;

                data[i] = Mathf.Clamp(v, -1f, 1f);
            }

            AudioClip c = AudioClip.Create("desert_music", n, 1, Rate, false);
            c.SetData(data, 0);
            return c;
        }
    }
}
