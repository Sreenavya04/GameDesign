using UnityEngine;

namespace DesertTemple
{
    /// <summary>
    /// Entry point. Runs automatically when ANY scene starts playing (RuntimeInitializeOnLoadMethod), creating the
    /// camera, lighting, managers, player, track and UI. No manual scene setup or Inspector wiring is needed.
    /// </summary>
    public class GameBootstrap : MonoBehaviour
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void AutoStart()
        {
            if (Object.FindObjectsByType<GameBootstrap>(FindObjectsSortMode.None).Length > 0) return;
            GameObject g = new GameObject("DesertTempleGame");
            g.AddComponent<GameBootstrap>();
        }

        void Awake()
        {
            Time.timeScale = 1f;
            Application.targetFrameRate = 60;
            QualitySettings.vSyncCount = 0;

            // remove lights that came with the default scene; we create our own
            Light[] old = Object.FindObjectsByType<Light>(FindObjectsSortMode.None);
            for (int i = 0; i < old.Length; i++) Destroy(old[i].gameObject);

            // ---- camera ----
            Camera cam = Camera.main;
            if (cam == null)
            {
                GameObject cg = new GameObject("Main Camera");
                cg.tag = "MainCamera";
                cam = cg.AddComponent<Camera>();
                cg.AddComponent<AudioListener>();
            }
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(0.95f, 0.84f, 0.62f);
            cam.nearClipPlane = 0.3f;
            cam.farClipPlane = 320f;
            cam.fieldOfView = 62f;
            if (cam.GetComponent<AudioListener>() == null) cam.gameObject.AddComponent<AudioListener>();
            if (cam.GetComponent<CameraFollow>() == null) cam.gameObject.AddComponent<CameraFollow>();

            // ---- light + atmosphere ----
            GameObject lg = new GameObject("Sun");
            Light sun = lg.AddComponent<Light>();
            sun.type = LightType.Directional;
            sun.color = new Color(1f, 0.92f, 0.75f);
            sun.intensity = 1.25f;
            sun.shadows = LightShadows.None;
            lg.transform.rotation = Quaternion.Euler(50f, -30f, 0f);

            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
            RenderSettings.ambientLight = new Color(0.75f, 0.62f, 0.48f);
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.Linear;
            RenderSettings.fogStartDistance = 70f;
            RenderSettings.fogEndDistance = 210f;
            RenderSettings.fogColor = cam.backgroundColor;

            // ---- managers (each Awake registers its singleton) ----
            Transform root = transform;
            AudioManager audio = Child(root, "AudioManager").AddComponent<AudioManager>();
            GameManager gm = Child(root, "GameManager").AddComponent<GameManager>();
            PowerUpManager pu = Child(root, "PowerUpManager").AddComponent<PowerUpManager>();

            // ---- player ----
            GameObject pg = new GameObject("Player");
            pg.transform.SetParent(root, false);
            PlayerController player = pg.AddComponent<PlayerController>();
            player.SetCharacter(GameManager.SelectedCharacter);

            // ---- endless track ----
            GameObject tg = Child(root, "Track");
            TrackManager track = tg.AddComponent<TrackManager>();
            track.cam = cam;
            track.sun = sun;

            // ---- UI ----
            UIManager ui = Child(root, "UI").AddComponent<UIManager>();
            ui.Build();

            gm.GoToMenu();
        }

        static GameObject Child(Transform parent, string name)
        {
            GameObject g = new GameObject(name);
            g.transform.SetParent(parent, false);
            return g;
        }
    }
}
