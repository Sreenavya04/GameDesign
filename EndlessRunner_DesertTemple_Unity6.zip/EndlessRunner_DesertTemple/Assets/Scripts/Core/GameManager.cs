using UnityEngine;

namespace DesertTemple
{
    public enum GameState { Menu, Playing, Paused, GameOver }

    /// <summary>Owns the game state, score, speed and high score.</summary>
    [DefaultExecutionOrder(-100)]
    public class GameManager : MonoBehaviour
    {
        public static GameManager Instance;

        public const string HighScoreKey = "DT_HighScore";
        public const string CharacterKey = "DT_Character";

        public GameState State { get; private set; }

        public float BaseSpeed = 12f;
        public float MaxSpeed = 30f;
        public float SpeedGainPerMeter = 0.006f;
        public int MaxHealth = 3;

        public float Speed { get; private set; }
        public float Distance { get; private set; }
        public int Score { get { return Mathf.FloorToInt(scoreF); } }
        public int Coins { get; private set; }
        public int Gems { get; private set; }
        public int Health { get; private set; }
        public int HighScore { get; private set; }
        public bool NewHighScore { get; private set; }

        float scoreF;
        float stumbleTimer;      // brief slow-down after being hit

        void Awake()
        {
            Instance = this;
            HighScore = PlayerPrefs.GetInt(HighScoreKey, 0);
            State = GameState.Menu;
        }

        /// <summary>Difficulty 0..1 based on a distance in metres.</summary>
        public static float DifficultyAt(float distance)
        {
            return Mathf.Clamp01(distance / 3000f);
        }

        public float Difficulty { get { return DifficultyAt(Distance); } }

        void Update()
        {
            if (State == GameState.Playing)
            {
                InputHelper.Poll();
                if (InputHelper.Pause) Pause();

                if (stumbleTimer > 0f) stumbleTimer -= Time.deltaTime;
                float stumble = stumbleTimer > 0f ? 0.55f : 1f;
                float baseSpeed = Mathf.Min(MaxSpeed, BaseSpeed + Distance * SpeedGainPerMeter);
                Speed = baseSpeed * PowerUpManager.Instance.SpeedMultiplier * stumble;

                float dz = Speed * Time.deltaTime;
                Distance += dz;
                scoreF += dz * 0.5f * PowerUpManager.Instance.ScoreMultiplier;
            }
            else if (State == GameState.Paused)
            {
                InputHelper.Poll();
                if (InputHelper.Pause) Resume();
            }
        }

        public void ResetRun()
        {
            Time.timeScale = 1f;
            Distance = 0f;
            scoreF = 0f;
            Coins = 0;
            Gems = 0;
            Health = MaxHealth;
            Speed = BaseSpeed;
            stumbleTimer = 0f;
            NewHighScore = false;
            PowerUpManager.Instance.ResetAll();
            TrackManager.Instance.ResetTrack();
            PlayerController.Instance.ResetPlayer();
        }

        public void StartRun()
        {
            ResetRun();
            State = GameState.Playing;
            AudioManager.Instance.PlayClick();
        }

        public void Restart()
        {
            StartRun();
        }

        public void GoToMenu()
        {
            ResetRun();
            State = GameState.Menu;
        }

        public void Pause()
        {
            if (State != GameState.Playing) return;
            State = GameState.Paused;
            Time.timeScale = 0f;
        }

        public void Resume()
        {
            if (State != GameState.Paused) return;
            State = GameState.Playing;
            Time.timeScale = 1f;
        }

        public void GameOver()
        {
            if (State != GameState.Playing) return;
            State = GameState.GameOver;
            if (Score > HighScore)
            {
                HighScore = Score;
                NewHighScore = true;
                PlayerPrefs.SetInt(HighScoreKey, HighScore);
                PlayerPrefs.Save();
            }
            AudioManager.Instance.PlayGameOver();
        }

        // ---- scoring API -------------------------------------------------
        public void AddScore(int points)
        {
            scoreF += points * PowerUpManager.Instance.ScoreMultiplier;
        }

        public void AddCoin(int amount = 1) { Coins += amount; }
        public void AddGem(int amount = 1) { Gems += amount; }

        /// <summary>Returns true if the player is dead after the damage.</summary>
        public bool Damage(int amount)
        {
            Health -= amount;
            stumbleTimer = 1.2f;
            if (Health < 0) Health = 0;
            return Health <= 0;
        }

        public static int SelectedCharacter
        {
            get { return PlayerPrefs.GetInt(CharacterKey, 0); }
            set { PlayerPrefs.SetInt(CharacterKey, value); PlayerPrefs.Save(); }
        }
    }
}
