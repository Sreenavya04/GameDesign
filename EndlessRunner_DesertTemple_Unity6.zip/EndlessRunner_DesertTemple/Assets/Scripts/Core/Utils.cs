using System;
using System.Collections.Generic;
using UnityEngine;
#if ENABLE_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
using UnityEngine.InputSystem;
#endif

namespace DesertTemple
{
    /// <summary>Shared colour palette (matches the reference image: gold, sandstone, brown, turquoise).</summary>
    public static class Pal
    {
        public static readonly Color Sand = new Color(0.93f, 0.78f, 0.50f);
        public static readonly Color Sandstone = new Color(0.80f, 0.58f, 0.32f);
        public static readonly Color SandstoneDark = new Color(0.55f, 0.37f, 0.20f);
        public static readonly Color Brown = new Color(0.30f, 0.18f, 0.09f);
        public static readonly Color DarkBrown = new Color(0.14f, 0.08f, 0.04f);
        public static readonly Color Gold = new Color(1.00f, 0.78f, 0.18f);
        public static readonly Color Teal = new Color(0.10f, 0.72f, 0.66f);
        public static readonly Color Skin = new Color(0.86f, 0.64f, 0.48f);
        public static readonly Color Green = new Color(0.20f, 0.55f, 0.22f);
        public static readonly Color Water = new Color(0.15f, 0.75f, 0.85f);
        public static readonly Color Fire = new Color(1.00f, 0.55f, 0.10f);
    }

    /// <summary>Creates and caches materials. Copies the render pipeline's default material so it works in Built-in and URP.</summary>
    public static class Mats
    {
        static Material baseMat;
        static readonly Dictionary<long, Material> cache = new Dictionary<long, Material>();

        static void EnsureBase()
        {
            if (baseMat != null) return;
            GameObject g = GameObject.CreatePrimitive(PrimitiveType.Cube);
            baseMat = g.GetComponent<Renderer>().sharedMaterial;
            UnityEngine.Object.Destroy(g);
        }

        public static Material Get(Color c, float emission = 0f)
        {
            EnsureBase();
            Color32 c32 = c;
            long key = (long)c32.r | ((long)c32.g << 8) | ((long)c32.b << 16) | ((long)c32.a << 24)
                       | ((long)Mathf.RoundToInt(emission * 100f) << 32);
            Material m;
            if (cache.TryGetValue(key, out m) && m != null) return m;

            m = new Material(baseMat);
            m.color = c;
            if (m.HasProperty("_BaseColor")) m.SetColor("_BaseColor", c);
            if (m.HasProperty("_Glossiness")) m.SetFloat("_Glossiness", 0.12f);
            if (m.HasProperty("_Smoothness")) m.SetFloat("_Smoothness", 0.12f);
            if (m.HasProperty("_Metallic")) m.SetFloat("_Metallic", 0f);
            if (emission > 0f)
            {
                m.EnableKeyword("_EMISSION");
                m.SetColor("_EmissionColor", c * emission);
            }
            cache[key] = m;
            return m;
        }
    }

    /// <summary>Quick primitive builder.</summary>
    public static class Prim
    {
        public static GameObject Make(PrimitiveType type, Transform parent, Vector3 localPos, Vector3 scale, Color color,
                                      float emission = 0f, Vector3? euler = null, string name = null)
        {
            GameObject g = GameObject.CreatePrimitive(type);
            Collider col = g.GetComponent<Collider>();
            if (col != null) UnityEngine.Object.Destroy(col);
            if (name != null) g.name = name;
            g.transform.SetParent(parent, false);
            g.transform.localPosition = localPos;
            g.transform.localScale = scale;
            if (euler.HasValue) g.transform.localRotation = Quaternion.Euler(euler.Value);
            Renderer r = g.GetComponent<Renderer>();
            r.sharedMaterial = Mats.Get(color, emission);
            r.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            return g;
        }

        public static GameObject Cube(Transform p, Vector3 pos, Vector3 s, Color c, float em = 0f, Vector3? e = null)
        { return Make(PrimitiveType.Cube, p, pos, s, c, em, e); }
        public static GameObject Sphere(Transform p, Vector3 pos, Vector3 s, Color c, float em = 0f, Vector3? e = null)
        { return Make(PrimitiveType.Sphere, p, pos, s, c, em, e); }
        public static GameObject Cyl(Transform p, Vector3 pos, Vector3 s, Color c, float em = 0f, Vector3? e = null)
        { return Make(PrimitiveType.Cylinder, p, pos, s, c, em, e); }
        public static GameObject Capsule(Transform p, Vector3 pos, Vector3 s, Color c, float em = 0f, Vector3? e = null)
        { return Make(PrimitiveType.Capsule, p, pos, s, c, em, e); }

        /// <summary>4-sided pyramid (base 1x1, height 1, pivot at the base centre). Used for spikes, gems, mountains, pyramids.</summary>
        public static GameObject Pyramid(Transform p, Vector3 pos, Vector3 s, Color c, float em = 0f, Vector3? e = null)
        {
            GameObject g = new GameObject("Pyramid");
            g.transform.SetParent(p, false);
            g.transform.localPosition = pos;
            g.transform.localScale = s;
            if (e.HasValue) g.transform.localRotation = Quaternion.Euler(e.Value);
            g.AddComponent<MeshFilter>().sharedMesh = MeshLib.Pyramid();
            MeshRenderer r = g.AddComponent<MeshRenderer>();
            r.sharedMaterial = Mats.Get(c, em);
            r.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            return g;
        }

        public static BoxCollider Trigger(GameObject g, Vector3 center, Vector3 size)
        {
            BoxCollider b = g.AddComponent<BoxCollider>();
            b.center = center;
            b.size = size;
            b.isTrigger = true;
            return b;
        }
    }

    public static class MeshLib
    {
        static Mesh pyramid;

        public static Mesh Pyramid()
        {
            if (pyramid != null) return pyramid;
            Vector3 a = new Vector3(-0.5f, 0, -0.5f);
            Vector3 b = new Vector3(0.5f, 0, -0.5f);
            Vector3 c = new Vector3(0.5f, 0, 0.5f);
            Vector3 d = new Vector3(-0.5f, 0, 0.5f);
            Vector3 t = new Vector3(0, 1, 0);
            // separate vertices per face for flat shading
            Vector3[] v = new Vector3[]
            {
                a, t, b,   // front (-z)
                b, t, c,   // right (+x)
                c, t, d,   // back (+z)
                d, t, a,   // left (-x)
                a, b, c, d // base
            };
            int[] tris = new int[]
            {
                0, 1, 2,
                3, 4, 5,
                6, 7, 8,
                9, 10, 11,
                12, 13, 14, 12, 14, 15
            };
            Mesh m = new Mesh();
            m.name = "Pyramid";
            m.vertices = v;
            m.triangles = tris;
            m.RecalculateNormals();
            m.RecalculateBounds();
            pyramid = m;
            return m;
        }
    }

    /// <summary>Marks a pooled object so it can be returned to the pool.</summary>
    public class PooledObject : MonoBehaviour
    {
        public string key;
        public bool inPool;
    }

    public static class Pool
    {
        static readonly Dictionary<string, Stack<GameObject>> free = new Dictionary<string, Stack<GameObject>>();
        static Transform root;

        static void EnsureRoot()
        {
            if (root != null) return;
            GameObject g = new GameObject("_Pool");
            root = g.transform;
        }

        public static GameObject Get(string key, Func<GameObject> create)
        {
            EnsureRoot();
            Stack<GameObject> st;
            if (!free.TryGetValue(key, out st))
            {
                st = new Stack<GameObject>();
                free[key] = st;
            }
            GameObject go = null;
            while (st.Count > 0 && go == null) go = st.Pop();
            if (go == null)
            {
                go = create();
                PooledObject po = go.AddComponent<PooledObject>();
                po.key = key;
            }
            go.GetComponent<PooledObject>().inPool = false;
            go.SetActive(true);
            return go;
        }

        public static void Release(GameObject go)
        {
            if (go == null) return;
            PooledObject po = go.GetComponent<PooledObject>();
            if (po == null) { UnityEngine.Object.Destroy(go); return; }
            if (po.inPool) return;
            EnsureRoot();
            po.inPool = true;
            go.SetActive(false);
            go.transform.SetParent(root, false);
            Stack<GameObject> st;
            if (!free.TryGetValue(po.key, out st))
            {
                st = new Stack<GameObject>();
                free[po.key] = st;
            }
            st.Push(go);
        }
    }

    /// <summary>Keyboard + swipe input that works with the old Input Manager or the new Input System package.</summary>
    public static class InputHelper
    {
        public static bool Left, Right, Jump, Slide, Pause;
        static bool tracking;
        static Vector2 startPos;
        const float SwipeMin = 55f;

        public static void Poll()
        {
            Left = Right = Jump = Slide = Pause = false;
#if ENABLE_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
            Keyboard k = Keyboard.current;
            if (k != null)
            {
                Left = k.aKey.wasPressedThisFrame || k.leftArrowKey.wasPressedThisFrame;
                Right = k.dKey.wasPressedThisFrame || k.rightArrowKey.wasPressedThisFrame;
                Jump = k.wKey.wasPressedThisFrame || k.upArrowKey.wasPressedThisFrame || k.spaceKey.wasPressedThisFrame;
                Slide = k.sKey.wasPressedThisFrame || k.downArrowKey.wasPressedThisFrame;
                Pause = k.pKey.wasPressedThisFrame || k.escapeKey.wasPressedThisFrame;
            }
            Pointer p = Pointer.current;
            if (p != null)
            {
                if (p.press.wasPressedThisFrame) { tracking = true; startPos = p.position.ReadValue(); }
                else if (tracking && p.press.isPressed) ResolveSwipe(p.position.ReadValue() - startPos);
                if (p.press.wasReleasedThisFrame) tracking = false;
            }
#else
            Left = Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.LeftArrow);
            Right = Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.RightArrow);
            Jump = Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.Space);
            Slide = Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.DownArrow);
            Pause = Input.GetKeyDown(KeyCode.P) || Input.GetKeyDown(KeyCode.Escape);

            if (Input.touchCount > 0)
            {
                Touch t = Input.GetTouch(0);
                if (t.phase == TouchPhase.Began) { tracking = true; startPos = t.position; }
                else if (tracking && (t.phase == TouchPhase.Moved || t.phase == TouchPhase.Stationary))
                    ResolveSwipe(t.position - startPos);
                if (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled) tracking = false;
            }
            else
            {
                if (Input.GetMouseButtonDown(0)) { tracking = true; startPos = Input.mousePosition; }
                else if (tracking && Input.GetMouseButton(0))
                    ResolveSwipe((Vector2)Input.mousePosition - startPos);
                if (Input.GetMouseButtonUp(0)) tracking = false;
            }
#endif
        }

        static void ResolveSwipe(Vector2 d)
        {
            if (d.magnitude < SwipeMin) return;
            if (Mathf.Abs(d.x) > Mathf.Abs(d.y)) { if (d.x > 0) Right = true; else Left = true; }
            else { if (d.y > 0) Jump = true; else Slide = true; }
            tracking = false; // one swipe per touch
        }
    }
}
