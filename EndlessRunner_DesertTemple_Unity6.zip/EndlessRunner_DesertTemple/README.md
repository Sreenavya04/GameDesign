# ENDLESS RUNNER – DESERT TEMPLE (Unity 3D)

A 3D three-lane endless runner. Female **and** male adventurer, 14 collectibles/power-ups, 10 obstacle types,
6 progressively changing environments, full UI, procedural audio, high-score saving.

> **Honest status: this project was written without access to the Unity Editor, so it has NOT been compiled,
> run or play-tested.** See "Not tested / known limitations" below. Expect to fix a few small compile errors
> or visual tweaks on first open.

## How to open and run
1. Install Unity 6 (tested versions unknown; written for 2022.3 LTS / Unity 6) through Unity Hub.
2. Unity Hub -> **Add** -> select this `EndlessRunner_DesertTemple` folder. If Hub warns about the editor
   version, choose your installed 2022.3 / Unity 6 version and let it upgrade.
3. Wait for the first import. The Editor script auto-creates `Assets/Scenes/DesertTemple.unity` and sets Build Settings.
   (If not, use the menu **Tools > Desert Temple > Setup Project**.)
4. Open `Assets/Scenes/DesertTemple.unity` (or **Tools > Desert Temple > Open Game Scene**) and press **Play**.
   Pressing Play in *any* scene works: `GameBootstrap` builds camera, light, managers, player, track and UI by itself.
5. Windows build: **Tools > Desert Temple > Build Windows (.exe)** -> `Builds/Windows/`.

## Controls
| Action | PC | Mobile |
|---|---|---|
| Move lane | A / D or Left / Right | Swipe left / right |
| Jump | W / Up / Space | Swipe up |
| Slide | S / Down | Swipe down |
| Pause | P / Esc | Pause button |

## Features
- Third-person camera, 3 lanes, auto-run, speed increases with distance, 3 health hearts.
- Characters: female + male adventurer (pick on the main menu, saved in PlayerPrefs), built from primitives
  with procedural Idle / Run / Jump / Slide / Lean-turn / Collect / Stumble / Fall animation.
- Collectibles: Golden Coin +10, Ankh +25, Gem +20, Scarabaeus +30, Mini Idol +40,
  Sand Hourglass (time bonus), Sun Orb (shield), Palm Leaf (magnet), Ancient Scroll (score x2).
- Power-ups: Speed Boost, Shield, Magnet, Invincibility, Score Multiplier (HUD shows active ones + time left).
- Obstacles: Falling Stone Block, Spikes, Rolling Boulder, Broken Bridge (jump), Moving Wall, Fire Trap,
  Sand Pit, Statue Guardian, Swinging Axe (slide/time it), Collapsing Pillar.
- Environments (600 m each, blended sky/fog/light): Temple Entrance, Sandy Path, Inner Temple Corridor,
  Broken Bridge, Oasis Ruins, Sunset Dunes.
- Endless pooled track (9 recycled segments), pooled obstacles / collectibles / decorations.
- UI: Main Menu (Play / Settings / Exit / character select), Settings (music & SFX toggles), HUD (pause, hearts,
  coins, gems, score, distance, power-ups, zone progress bar), Pause menu, Game Over (score, coins, gems,
  distance, high score, Retry, Main Menu).
- Audio: all sound effects and a looping music track are synthesised in code (no audio files).

## Code map (`Assets/Scripts`)
`Core/` GameBootstrap, GameManager, Utils (materials, primitives, pooling, input) - `Player/` PlayerController,
CharacterBuilder (+PlayerAnimator), CameraFollow - `Track/` TrackManager - `Obstacles/` Obstacle -
`Collectibles/` Collectible, PowerUpManager - `UI/` UIManager - `Audio/` AudioManager -
`Assets/Editor/` DesertTempleEditorTools.

## Not tested / known limitations (please read)
- Never compiled or run in Unity: no Unity Editor was available. No Windows .exe could be built.
- Everything is **procedural and primitive-based** (cubes, spheres, a generated pyramid mesh). It follows the reference
  image's palette and objects but will NOT match its illustrated art. Replace models with real art later.
- No `.prefab`, `.anim` or Animator Controller files exist: objects are built and pooled in code, animation is procedural.
  (So the "Unity Animator" and prefab-asset requirements are not met as files.)
- The UI uses Unity's legacy `Text` + built-in font (no TextMeshPro import needed).
- Visual effects are limited to emissive glow and flickering flames; no particle systems.
- Unity 6 / new Input System: the code supports both, but if you enable the Input System package and set
  Active Input Handling to "Input System (New)" only, make sure the package is installed.

## Tuning
`GameManager` (speeds, health), `PlayerController` (jump/gravity/lane speed), `TrackManager` (spawn chances, themes).

## Package note
This project intentionally ships **without** `Packages/manifest.json`. Unity generates the correct default package list for your editor version on first open (the earlier hand-written manifest clashed with Unity 6).
